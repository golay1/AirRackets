<?php


use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('index',function(){
	return view('index');
});
Route::get('configs',function(){
	return view('configs');
});
Route::get('about',function(){
	return view('about');
});
Route::get('contact',function(){
	return view('contact');
});

Route::get('store',function(){
	return view('store');
});
Route::match(['get','post'],'login',function(){
	return view('login');
});
Route::match(['get','post'],'register',function(){
	return view('register');
});
Route::match(['get','post'],'forgotpassword',function(){
	return view('forgotpassword');	
	
});
Route::match(['get','post'],'changepass',function(){
	return view('changepass');	
	
});
Route::match(['get','post'],'lockscreen',function(){
	return view('lockscreen');	
	
});
Route::match(['get','post'],'player-dashboard',function(){
	return view('player-dashboard');		
});
Route::match(['get','post'],'player-contacts',function(){
	return view('player-contacts');		
});
Route::match(['get','post'],'player-activities',function(){
	return view('player-activities');		
});
Route::match(['get','post'],'player-create-team',function(){
	return view('player-create-team');		
});
Route::match(['get','post'],'player-join-team',function(){
	return view('player-join-team');		
});
Route::match(['get','post'],'player-messages',function(){
	return view('player-messages');		
});
Route::match(['get','post'],'player-my-team',function(){
	return view('player-my-team');		
});
Route::match(['get','post'],'player-product',function(){
	return view('player-product');		
});
Route::match(['get','post'],'player-profile',function(){
	return view('player-profile');		
});
Route::match(['get','post'],'player-shops',function(){
	return view('player-shops');		
});
Route::match(['get','post'],'player-team-detail',function(){
	return view('player-team-detail');		
});
Route::match(['get','post'],'admin-dashboard',function(){
	return view('admin-dashboard');		
});
Route::match(['get','post'],'admin-contacts',function(){
	return view('admin-contacts');		
});
Route::match(['get','post'],'admin-createactivities',function(){
	return view('admin-createactivities');		
});
Route::match(['get','post'],'admin-create-team',function(){
	return view('admin-create-team');		
});
Route::match(['get','post'],'admin-join-team',function(){
	return view('admin-join-team');		
});
Route::match(['get','post'],'admin-list-team',function(){
	return view('admin-list-team');		
});
Route::match(['get','post'],'admin-messages',function(){
	return view('admin-messages');		
});
Route::match(['get','post'],'admin-my-team',function(){
	return view('admin-my-team');		
});
Route::match(['get','post'],'admin-product',function(){
	return view('admin-pdocut');		
});
Route::match(['get','post'],'admin-profile',function(){
	return view('admin-profile');		
});
Route::match(['get','post'],'admin-seeactivities',function(){
	return view('admin-seeactivities');		
});
Route::match(['get','post'],'admin-shops',function(){
	return view('admin-shops');		
});
Route::match(['get','post'],'admin-storeslist',function(){
	return view('admin-storeslist');		
});
Route::match(['get','post'],'admin-team-detail',function(){
	return view('admin-team-detail');		
});
Route::match(['get','post'],'store-dashboard',function(){
	return view('store-dashboard');		
});
Route::match(['get','post'],'store-create-product',function(){
	return view('store-create-product');		
});
Route::match(['get','post'],'store-list-products-shown',function(){
	return view('store-list-products-shown');		
});
Route::match(['get','post'],'store-load-product',function(){
	return view('store-load-product');		
});
Route::match(['get','post'],'store-product-orders',function(){
	return view('store-product-orders');		
});
Route::match(['get','post'],'store-profile',function(){
	return view('store-profile');		
});
