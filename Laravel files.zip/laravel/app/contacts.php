<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class contacts extends Model
{
    	use DatePresenter;

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'contacts';

}
