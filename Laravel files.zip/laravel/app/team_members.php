<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class team_members extends Model
{
    	use DatePresenter;

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'team_members';

}
