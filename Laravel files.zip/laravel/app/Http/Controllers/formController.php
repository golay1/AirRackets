<?php



namespace App\Http\Controllers;

use App\form;

use Illuminate\Http\Request;

class formController extends Controller
{
	public function list()
	{
		$form= new form();
		$result=$form->all();
		return $result;
	}
	
    public function getformByid($id)
	{
		$form= new form();
		$result=$form->find($id);
		return $result;
	}
}
