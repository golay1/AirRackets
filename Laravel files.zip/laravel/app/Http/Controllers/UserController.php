<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        $users = User::orderBy('name', 'asc')->get();

        return view('users.index', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        $this->user_reg('auth');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store()
    {
		$this->user_reg->store($request->all());

		return redirect('user')->with('ok', trans('back/users.created'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
		return view('users.show', compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        if (auth()->user()->getAuthIdentifier() == $user->id)
            return view('users.edit', compact('user'));
        else
            return view('accessDenied');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update($id)
    {
        if (auth()->user()->getAuthIdentifier() != $request->user_id)
            return view('accessDenied');


        $user = User::findOrFail($request->user_id);

        $this->validate(request(), [
            'name' => 'required|min:3|max:50',
            'address' => 'max:50',
            'phone' => 'max:15',

        ]);

        $email = $request->input('email');
        if ($email && ($email !== $user->email))
        {
            $this->validate(request(), [
                'email' => 'email|max:50|unique:users',
            ]);
            $user->email = $email;
        }

        if ($request->input('name'))
            $user->name = $request->name;
        if ($request->input('address'))
            $user->address = $request->address;
        if ($request->input('phone'))
            $user->phone = $request->phone;

        $user->save();

        return redirect('/users/' . $user->id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        if (auth()->user()->getAuthIdentifier() != $user->id)
            return view('accessDenied');

        $user->delete();

        return redirect('home');
    }
}
