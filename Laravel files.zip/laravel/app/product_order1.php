<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class product_order1 extends Model
{
    	use DatePresenter;

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'preoduct_order1';
	
	/**
	 * The timestamps.
	 *
	 * @var bool
	 */
	public $timestamps = false;

}
