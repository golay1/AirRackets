$('#send').on('click', function () {
    var subject = $('#subject').val();
    email = $('email');

    var body = 'Name: ' + $('#name').val() + '\n' + 'Email: ' + email + '\n\n' + $('#message').val()
   
 filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
if (filter.test(email.value)) {
  
    var link = 'mailto:support@colorlib.com?subject=' + subject + '&body=' + body;
    window.location.href = encodeURI(link);
}
  

});

$(document).ready(function () {

    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });

    $('#ride-switch').on('click', function () {
        $('#ride-switch').toggleClass('active');
    })

    $('#carry-switch').on('click', function () {
        $('#carry-switch').toggleClass('active');
    })

});

function openWindow(url) {
    window.location.href = url;
}

function changeProductImage(image) {
    document.getElementById("product-img").src = image;
}