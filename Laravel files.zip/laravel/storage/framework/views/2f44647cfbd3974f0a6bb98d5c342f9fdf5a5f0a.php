<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
            crossorigin="anonymous">
        <link rel="stylesheet" href="public/font-awesome-4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="public/css/styles.css">
    </head>
    <body>
    <?php
 $host= "localhost:3306";
$dbUsername= "gdn8015_larauser";
$dbPassword= "airrackets;5";
$dbName="gdn8015_lara1";

try{
$pdo=new PDO("mysql:host=$host; dbname=$dbName", $dbUsername, $dbPassword);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
echo"Connection Successful";
}
catch(PDOException $error){
echo $error->getMessage();
}
       $varid = $_GET['varid'];
       echo $varid;
       echo"hello";
	   $id= $varid;
	   if($varid)
	     STATIC $x = 0;
    ?>
	
        <div class="wrapper">

            <nav id="sidebar">
                <div class="sidebar-header">
                    <img class="mr-2" src="public/img-proyect/logo35x35.png">
                    <span class="side-label">AirRackets</span>
                </div>
        
                <ul class="list-unstyled components" style="border: none">
                    <p>
                        <img style="height: 35px; border-radius: 20px;" class="mr-2" src="<?php $qu= $pdo->prepare("SELECT photo FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?>">
                        <span class="side-label"><?php $qu= $pdo->prepare("SELECT name FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?> </span>
                    </p>
                    <li>
                        <a href='admin-dashboard? varid=<?php echo $varid ?>'><i class="fa fa-tachometer mr-2" aria-hidden="true"></i> <span class="side-label">Dashboard</span></a>
                    </li>
                    <li>
                        <a href='admin-contacts? varid=<?php echo $varid ?>'><i class="fa fa-address-book mr-2" aria-hidden="true"></i> <span class="side-label">Contacts</span></a>
                    </li>
                    <li>
                        <a href='admin-messages? varid=<?php echo $varid ?>& mid=  <?php echo 0 ?>'><i class="fa fa-comments mr-2" aria-hidden="true"></i> <span class="side-label">Messages</span></a>
                    </li>
					<li>
                        <a href="#activitiesSubMenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <i class="fa fa-trophy mr-2" aria-hidden="true"></i> 
                            <span class="side-label">Activities</span>
							<span class="badge badge-primary ml-auto" style="float: center; background: #00bcd4;">2</span>
                        </a>
                        <ul class="collapse list-unstyled" id="activitiesSubMenu">
                            <li>
                                <a href='admin-createactivities? varid=<?php echo $varid ?>'><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Create Activities</span></a>
                            </li>
                            <li>
                                <a href='admin-seeactivities? varid=<?php echo $varid ?>'><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">See Activities</span></a>
                            </li>
                        </ul>
                    </li>
					<li>
                        <a href="#teamSubMenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <i class="fa fa-group mr-2" aria-hidden="true"></i> 
                            <span class="side-label">Team</span>
                        </a>
                        <ul class="collapse list-unstyled" id="teamSubMenu">
                            <li>
                                <a href='admin-my-team? varid=<?php echo $varid ?>'><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">See Team</span></a>
                            </li>
                            <li>
                                <a href='admin-create-team? varid=<?php echo $varid ?>'><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Create Team</span></a>
                            </li>
                            <li>
                                <a href='admin-join-team? varid=<?php echo $varid ?>'><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Join a Team</span></a>
                            </li>
							<li>
                                <a href='admin-list-team? varid=<?php echo $varid ?>'><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">List of Teams</span></a>
                            </li>
                        </ul>
                    </li>
					<li>
                        <a href="#shopsSubMenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <i class="fa fa-shopping-cart mr-2" aria-hidden="true"></i> 
                            <span class="side-label">Shops</span>
                        </a>
                        <ul class="collapse list-unstyled" id="shopsSubMenu">
                            <li>
                                <a href='admin-shops? varid=<?php echo $varid ?>'><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Shops</span></a>
                            </li>
                            <li>
                                <a href='admin-storeslist? varid=<?php echo $varid ?>'><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Stores List</span></a>
                            </li>
                        </ul>
                    </li>
					<li>
                        <a href="#configSubMenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <i class="fa fa-plus-square-o mr-2" aria-hidden="true"></i> 
                            <span class="side-label">Configurations</span>
                        </a>
                        <ul class="collapse list-unstyled" id="configSubMenu">
                            <li>
                                <a href='admin-profile? varid=<?php echo $varid ?>'><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Profile</span></a>
                            </li>
                            <li>
                                <a href='changepass? varid=<?php echo $varid ?>'><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Recover Password</span></a>
                            </li>
                            <li>
                                <a href='lockscreen? varid=<?php echo $varid ?>'><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Screenlock</span></a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href='index'><i class="fa fa-sign-out mr-2" aria-hidden="true"></i> <span class="side-label">Sign Off</span></a>

                    </li>
                </ul>
            </nav>

            <div id="content" class="d-flex flex-column flex-grow-1">
                <nav id="header" class="navbar navbar-expand-lg navbar-light bg-white" style="border-bottom: 1px solid #e0e0e0;">
                    <div class="container-fluid px-0" style="justify-content: start;">
                        <button type="button" id="sidebarCollapse" class="btn btn-light bg-white" style="border: none; color: #bdbdbd">
                            <i class="fa fa-bars"></i>
                        </button>
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href='admin-dashboard? varid=<?php echo $varid ?>'>Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href='admin-contacts? varid=<?php echo $varid ?>'>Contact</a>
                            </li>
                        </ul>
                        <form class="form-inline ml-3">
                            <div class="header-search" style="position: relative;">
                                <input style="padding-right: 30px; font-size: 14px;" type="text" class="form-control" placeholder="Search">
                                <i class="fa fa-search" aria-hidden="true"></i>
                            </div>
                        </form>
                        <ul class="navbar-nav ml-auto notification-icons">
                            <li class="d-inline-block mr-3 nav-item dropdown" style="position: relative">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="true"><i class="fa fa-comment-o fa-lg"></i></a>
                                <div class="badge badge-danger">3</div>
                                <div class="dropdown-menu p-0 shadow" style="width: 300px; left: -260px;">
                                    <div class="dorpdown-item message-item">
                                        <div class="d-flex">
                                            <img class="message-img align-self-center" src="public/img-proyect/user1-128x128.jpg">
                                            <div class="flex-grow-1">
                                                <div class="message-name">Brad Diesel</div>
                                                <div class="message-tag">Gamer</div>
                                                <div class="message-time text-secondary"><i class="fa fa-clock-o"></i> 4 Hours Ago</div>
                                            </div>
                                            <i class="fa fa-star align-self-start text-danger"></i>
                                        </div>
                                    </div>
                                    <hr class="m-0">
                                    <div class="dorpdown-item message-item">
                                        <div class="d-flex">
                                            <img class="message-img align-self-center" src="public/img-proyect/user8-128x128.jpg">
                                            <div class="flex-grow-1">
                                                <div class="message-name">John Pierce</div>
                                                <div class="message-tag">Gamer</div>
                                                <div class="message-time text-secondary"><i class="fa fa-clock-o"></i> 4 Hours Ago</div>
                                            </div>
                                            <i class="fa fa-star align-self-start text-secondary"></i>
                                        </div>
                                    </div>
                                    <hr class="m-0">
                                    <div class="dorpdown-item message-item">
                                        <div class="d-flex">
                                            <img class="message-img align-self-center" src="public/img-proyect/user3-128x128.jpg">
                                            <div class="flex-grow-1">
                                                <div class="message-name">Nora Silverster</div>
                                                <div class="message-tag">Gamer</div>
                                                <div class="message-time text-secondary"><i class="fa fa-clock-o"></i> 4 Hours Ago</div>
                                            </div>
                                            <i class="fa fa-star align-self-start text-warning"></i>
                                        </div>
                                    </div>
                                    <hr class="m-0">
                                    <div class="dropdown-item message-item text-center" style="font-size: 14px;">
                                        <a href="admin-messages.php? varid=<?php echo $varid ?>">See all messages</a>     
                                    </div>
                                </div>
                            </li>
                            <li class="d-inline-block mr-3 nav-item dropdown" style="position: relative">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="true"><i class="fa fa-bell-o fa-lg"></i></a>
                                <div class="badge badge-warning">15</div>
                                <div class="dropdown-menu p-0 shadow" style="width: 300px; left: -260px;">
                                    <div class="dorpdown-item notification-item text-center text-secondary" style="font-size: 14px;">
                                        15 notifications
                                    </div>
                                    <hr class="m-0">
                                    <div class="dorpdown-item notification-item d-flex align-items-center">
                                        <i class="fa fa-envelope mx-2"></i>
                                        <div class="flex-grow-1">4 new messages</div>
                                        <div class="text-secondary" style="font-size: 12px;">3 min</div>
                                    </div>
                                    <hr class="m-0">
                                    <div class="dorpdown-item notification-item d-flex align-items-center">
                                        <i class="fa fa-group mx-2"></i>
                                        <div class="flex-grow-1">8 friend gamer</div>
                                        <div class="text-secondary" style="font-size: 12px;">12 hours</div>
                                    </div>
                                    <hr class="m-0">
                                    <div class="dorpdown-item notification-item d-flex align-items-center">
                                        <i class="fa fa-file mx-2"></i>
                                        <div class="flex-grow-1">3 new requests</div>
                                        <div class="text-secondary" style="font-size: 12px;">2 days</div>
                                    </div>
                                    <hr class="m-0">
                                    <div class="dorpdown-item notification-item text-center" style="font-size: 14px;">
                                        See all notifications
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div id="dashboard" class="flex-grow-1 main-content">
                    <div class="d-flex justify-content-between align-items-center p-3">
                        <h3 class="h3">Activities List</h3>
                        <div>
                            <a href="#">Home</a> / Activities List
                        </div>
                    </div>
                    <div class="card" style="margin-left: 10px; margin-right: 10px;">
                        <div class="card-header" style="color:white; border-bottom:none; background:gray;">
                            Activities list
                        </div>
                        <div class="card-body p-0">
                            <table class="table table-striped mb-0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Place</th>
                                        <th>Activity manager</th>
										<th>Date</th>
										<th>Hour</th>
                                        <th>Status</th>
                                        <th>Reason</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php $qu= $pdo->prepare("SELECT activity_id FROM activities WHERE activity_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
                                        <td><?php $qu= $pdo->prepare("SELECT place FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
										<td><?php $qu= $pdo->prepare("SELECT manager_name FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
										<td><?php $qu= $pdo->prepare("SELECT date FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
										<td><?php $qu= $pdo->prepare("SELECT time FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
                                        <td><div class="badge badge-success"><?php $qu= $pdo->prepare("SELECT status FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></div></td>
										<td><?php $qu= $pdo->prepare("SELECT description FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
                                    </tr>                                    
									<tr>
                                        <td><?php $qu= $pdo->prepare("SELECT activity_id FROM activities WHERE activity_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
                                        <td><?php $qu= $pdo->prepare("SELECT place FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
										<td><?php $qu= $pdo->prepare("SELECT manager_name FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
										<td><?php $qu= $pdo->prepare("SELECT date FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
										<td><?php $qu= $pdo->prepare("SELECT time FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
                                        <td><div class="badge badge-success"><?php $qu= $pdo->prepare("SELECT status FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></div></td>
										<td><?php $qu= $pdo->prepare("SELECT description FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
                                    </tr>                                    
									<tr>
                                        <td><?php $qu= $pdo->prepare("SELECT activity_id FROM activities WHERE activity_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
                                        <td><?php $qu= $pdo->prepare("SELECT place FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
										<td><?php $qu= $pdo->prepare("SELECT manager_name FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
										<td><?php $qu= $pdo->prepare("SELECT date FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
										<td><?php $qu= $pdo->prepare("SELECT time FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
                                        <td><div class="badge badge-success"><?php $qu= $pdo->prepare("SELECT status FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></div></td>
										<td><?php $qu= $pdo->prepare("SELECT description FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
                                    </tr>
									<tr>
                                        <td><?php $qu= $pdo->prepare("SELECT activity_id FROM activities WHERE activity_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
                                        <td><?php $qu= $pdo->prepare("SELECT place FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
										<td><?php $qu= $pdo->prepare("SELECT manager_name FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
										<td><?php $qu= $pdo->prepare("SELECT date FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
										<td><?php $qu= $pdo->prepare("SELECT time FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
                                        <td><div class="badge badge-success"><?php $qu= $pdo->prepare("SELECT status FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></div></td>
										<td><?php $qu= $pdo->prepare("SELECT description FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
                                    </tr>
									<tr>
                                        <td><?php $qu= $pdo->prepare("SELECT activity_id FROM activities WHERE activity_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
                                        <td><?php $qu= $pdo->prepare("SELECT place FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
										<td><?php $qu= $pdo->prepare("SELECT manager_name FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
										<td><?php $qu= $pdo->prepare("SELECT date FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
										<td><?php $qu= $pdo->prepare("SELECT time FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
                                        <td><div class="badge badge-success"><?php $qu= $pdo->prepare("SELECT status FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></div></td>
										<td><?php $qu= $pdo->prepare("SELECT description FROM activities WHERE activity_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <footer class="page-footer" style="border-top: 1px solid #e0e0e0;">
                    <div class="footer-copyright py-3 pl-3" style="color: #9E9E9E; font-weight: bold;">
                        Copyright &copy; 2020 <a style="color: #0091EA;" href="#">DiazApps</a>. All rights reserved.
                    </div>
                </footer>
            </div>
        </div>

        <!-- Scripts -->
        <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
			crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
            crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
            crossorigin="anonymous"></script>
        <script src="public/js/script.js"></script>
    </body>
</html><?php /**PATH /home/gdn8015/public_html/laravel/resources/views/admin-seeactivities.blade.php ENDPATH**/ ?>