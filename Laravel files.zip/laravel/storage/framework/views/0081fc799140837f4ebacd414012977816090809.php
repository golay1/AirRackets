<?php $__env->startSection('content'); ?>
	  <div class="text-center text-white title">Store</div>
	  
	  <!--section1products-->
	  <div class="row section2">
		<div class="col-sm-12">
			<div class="text-center" style="font-size:20px; color:#eb566c; margin-top:200px;">--- The best articles</div>
			<div class="text-center" style="font-size:50px;">What we have for you</div>
			<br><br>
		</div>
	  </div>
	  <div class="row section2">
		<div class="col-sm-2"></div>	
		<div class="col-sm-3">
			<img src="public/img-proyect/BLACK_STAR.jpg">
		</div>
		<div class="col-sm-3">
			<img src="public/img-proyect/BRAZIL_04.jpg">
		<br>
		</div>
		<div class="col-sm-3">
			<img src="public/img-proyect/FLAMINGO_04.jpg">
		</div>
	  </div>
	  
	  <div class="row section3">
		<div class="col-sm-2"></div>	
		<div class="col-sm-3">
			<div class="text-left" style="font-size:25px;"> PRO COMPETITION BLACK STAR</div>
			<div class="text-left" style="font-size:15px;"> PROFESSIONAL</div><br>
			<div><a class="text-left" style="font-size:18px; color:black;" href='login'>-> GET STARTED</a></div><br>
			<div class="text-right" style="font-size:30px; color:#eb566c;">.01</div>
		</div>
		<div class="col-sm-3">
			<div class="text-left" style="font-size:25px;"> PERFORMANCE BRAZIL</div>
			<div class="text-left" style="font-size:15px;"> PROFESSIONAL</div><br>
			<div><a class="text-left" style="font-size:18px; color:black;" href='login'>-> GET STARTED</a></div><br>
			<div class="text-right" style="font-size:30px; color:#eb566c;">.02</div>
		</div>
		<div class="col-sm-3">
			<div class="text-left" style="font-size:25px;"> PERFORMANCE FLAMINGO</div>
			<div class="text-left" style="font-size:15px;"> PROFESSIONAL</div><br>
			<div><a class="text-left" style="font-size:18px; color:black;" href='login'>-> GET STARTED</a></div><br>
			<div class="text-right" style="font-size:30px; color:#eb566c;">.03</div>
		</div>
	  </div>
	  <br><br><br><br><br><br>  
	  
	  <!--2nd row-->
	  <div class="row section2">
		<div class="col-sm-2"></div>	
		<div class="col-sm-3">
			<img src="public/img-proyect/BALL_01.jpg">
		</div>
		<div class="col-sm-3">
			<img src="public/img-proyect/BLACK_STAR.jpg">
		<br>
		</div>
		<div class="col-sm-3">
			<img src="public/img-proyect/ANGEL_04.jpg">
		</div>
	  </div>
	  
	  <div class="row section3">
		<div class="col-sm-2"></div>	
		<div class="col-sm-3">
			<div class="text-left" style="font-size:25px;"> BEACH BOAR MEDIUM SPEED</div>
			<div class="text-left" style="font-size:15px;"> PROFESSIONAL</div><br>
			<div><a class="text-left" style="font-size:18px; color:black;" href='login'>-> GET STARTED</a></div><br>
			<div class="text-right" style="font-size:30px; color:#eb566c;">.04</div>
		</div>
		<div class="col-sm-3">
			<div class="text-left" style="font-size:25px;"> PRO COMPETITION BLACK STAR</div>
			<div class="text-left" style="font-size:15px;"> PROFESSIONAL</div><br>
			<div><a class="text-left" style="font-size:18px; color:black;" href='login'>-> GET STARTED</a></div><br>
			<div class="text-right" style="font-size:30px; color:#eb566c;">.05</div>
		</div>
		<div class="col-sm-3">
			<div class="text-left" style="font-size:25px;"> PERFORMANCE ANGEL</div>
			<div class="text-left" style="font-size:15px;"> PROFESSIONAL</div><br>
			<div><a class="text-left" style="font-size:18px; color:black;" href='login'>-> GET STARTED</a></div><br>
			<div class="text-right" style="font-size:30px; color:#eb566c;">.06</div>
		</div>
	  </div>
	  <br><br><br><br><br><br>  
	  
	 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gdn8015/public_html/laravel/resources/views/store.blade.php ENDPATH**/ ?>