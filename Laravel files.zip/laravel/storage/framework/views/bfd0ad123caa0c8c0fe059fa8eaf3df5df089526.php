<!DOCTYPE html>
<html lang="en">
  <head>
	<title>AirRackets - Register</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
      crossorigin="anonymous">
    <link rel="stylesheet" href="public/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="public/css/loginstyle.css">
  </head>
  <body>
  <?php
  error_reporting(-1);
ini_set('display_errors', 'On');
set_error_handler("var_dump");
//PHP Validation
$host= "localhost:3306";
$dbUsername= "gdn8015_larauser";
$dbPassword= "airrackets;5";
$dbName="gdn8015_lara1";
try{
$pdo=new PDO("mysql:host=$host; dbname=$dbName", $dbUsername, $dbPassword);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

}
catch(PDOException $error){
echo $error->getMessage();
}
?>
    <script>
    //JS validation
    function validateForm()
{
       // Validate Email
    var email = $("#mail").val();
    if ((/(.+)@(.+){2,}\.(.+){2,}/.test(email)) || email=="" || email==null) { } else {
        alert("Please enter a valid email");
        return false;
    }
    var pass = $("#pass").val();
    if((pass.length<8)||(pass.length>10))
    {
        alert("Password must be between 8-10");
        return false;
    }
    var cpass = $("#cpass").val();
    if(!(pass==cpass))
    {
        alert("Passwords don't match");
        return false;
    }
    
  return true;
}
</script>
	
	

<?php
$nameErr="";
$emailErr="";
$cpasswordErr="";
$passwordErr="";
$flag=1;
$checkErr="";

  if (isset($_POST['name']) && isset($_POST['password'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
   
    $usertype = $_POST['usertype'];
    $password = $_POST['password'];
    $cpassword = $_POST['confirmpassword'];


    $stmt = $pdo->prepare("SELECT * FROM user WHERE email = ?");
    $stmt->bindParam(1, $email, PDO::PARAM_STR);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

 if (empty($_POST["name"])) {
    $nameErr = "Name is required";
    $flag=0;
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed"; 
      $flag=0;
    }
  }
  
//Validate Email format
if (empty($_POST["email"])) {
    $emailErr = "\nEmail is required";
    $flag=0;
  } else {
    $email = test_input($_POST["email"]);
    
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "\n*Invalid email format"; 
      $flag=0;
      }
    }


   


// Validate password strength
$uppercase = preg_match('@[A-Z]@', $password);
$lowercase = preg_match('@[a-z]@', $password);
$number    = preg_match('@[0-9]@', $password);
$specialChars = preg_match('@[^\w]@', $password);

if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < 8 || strlen($password)  >10) {
    $passwordErr= "\nPassword should be at between 8-10 characters in length and should include at least one upper case letter, one number, and one special character.";
    $flag=0;
} 

//Validate Confirm password   
if($cpassword!= $password){
$cpasswordErr="\n passwords dont match";
$flag=0;
}

if(!(isset($_POST['check']) && $_POST['check']!=""))
{
    $flag=0;
    $checkErr="\n Check box not checked";
}

//Validate already registered users
 if (!empty($user)) {
$emailErr= "\nemail already exists";
$flag=0;
} 


//All validation passed
        if($flag==1) {
      $pdo->beginTransaction();
      $pdo->exec("INSERT INTO user (name,email,password,usertype) VALUES('$name', '$email', '$password','$usertype')");
      $pdo->commit();
$to=$email;
$subject= "Registration Confirmation for" .$name;
$headers = "MIME-Version: 1.0 .Content-type: text/html; charset=iso-8859-1.";
$txt=" Welcome. Thank you for joining Air Rackets.It is the right app for players to form teams, compete and also make new friends -------- Air Rackets."  ;
$status=mail($to,$subject,$txt,$headers);
if($status==true)
{
forward("login");
}

       }
    }
  

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

function endsWith($string, $endString) 
{ 
    $len = strlen($endString); 
    if ($len == 0) { 
        return true; 
    } 
    return (substr($string, -$len) === $endString); 
} 

function forward($url)
{
    if (!headers_sent())
    {    
        header('Location: '.$url);
        exit;
        }
    else
        {  
        echo '<script type="text/javascript">';
        echo 'window.location.href="'.$url.'";';
        echo '</script>';
        echo '<noscript>';
        echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
        echo '</noscript>'; exit;
    }
}


?>

	<style>
.error {color: #FF0000;}
</style>
	  <div class="logo">
         <img src="public/img-proyect/logo200x200.png">
      </div>
	  <div class="mainlong">
        <p class="signinmsg" align="center">Register a new membership</p>
        <form class="form1"  method="POST" action="">
		<?php echo csrf_field(); ?> <!-- <?php echo e(csrf_field()); ?> -->
          <input class="forminput" type="text" align="center" placeholder="Full name" name="name" required minlength="4" maxlength="50"><span class="error" align="center"> <br> <?php echo $nameErr ?> </span>
          <input class="forminput" type="text" align="center" placeholder="Email" id="mail" name="email" required >
 <span class="error" align="center"> <br> <?php echo $emailErr ?> </span>
          		  <input class="password" type="password" align="center" placeholder="Password" name="password" required minlength="8" maxlength="10" id="pass"><span class="error" align="center" aria-live="polite" > <br> <?php echo $passwordErr ?> </span>

		  <input class="password" type="password" align="center" placeholder="Retype Password" name="confirmpassword" required minlength="8" maxlength="10" id="cpass"> <span class="error" align="center" > <br> <?php echo $cpasswordErr ?> </span>
		  <p class="usertype">
		  <label for="usertype">Type of user:</label><br>
		  <select name="usertype" id="type" required>
		    <option value="gamer">Gamer</option>
		    <option value="store">Store</option>
		    <option value="admin">Admin</option>
		  </select>
		  </p>
		  <p class="remember_me">
		    <label><input type="checkbox" name="check" id="remember_me">I agree to the terms</label><span class="error" align="center"> <br> <?php echo $checkErr ?> </span>

          </p>
		  <button  type="submit"  class="submit"  align="right" onclick=" return validateForm()" name="submit" >Register</button>
          <p class="loginoptions" align="left"><a href='login'>I already have a membership</a></p>
		</form>
      </div>

  <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
      crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
      crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
      crossorigin="anonymous"></script>
    <script src="public/js/script.js"></script>
  </body>
</html>
<?php /**PATH /home/gdn8015/public_html/laravel/resources/views/register.blade.php ENDPATH**/ ?>