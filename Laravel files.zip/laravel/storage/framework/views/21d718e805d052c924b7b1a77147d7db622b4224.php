<!DOCTYPE html>
<html lang="en">
  <head>
	<title>AirRackets - Store</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
      crossorigin="anonymous">
    <link rel="stylesheet" href="public/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="public/css/homestyle.css">
  </head>
  <body>
	<div id="main" class="d-flex flex-column">
	
	  <!--header-->
      <nav id="header" class="navbar navbar-expand-lg" style="background: #020230">
        <div class="container-fluid px-0">
          <img src="public/img-proyect/logo100x100.png" class="ml-5">
          <ul class="navbar-nav ml-auto mr-5">
            <li class="nav-item">
              <a class="nav-link text-white" href='index'>Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href='about'>About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href='store'>Store</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="https://hxk3518.uta.cloud">Blog</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href='contact'>Contact</a>
            </li>
          </ul>
          <button id="login" class="mx-5" onclick="document.location='login'">LOGIN</button>
        </div>
      </nav>
	  
	  
	  
	  <?php echo $__env->yieldContent('content'); ?>
	  
	  
	  <footer style="background: #010e22; padding-top: 200px;">
        <div class="container">
          <div class="d-flex align-items-center" style="margin-bottom: 100px;">
            <img src="public/img-proyect/logo200x200.png" class="mr-5">
            <div class="row mx-0 flex-grow-1">
              <div class="col-sm-4 d-flex flex-column align-items-center">
                <div>
                  <div class="text-white mb-3" style="font-size: 20px;">All Offers</div>
                  <div><a class="text-secondary mb-2" href="#">offers-1</a></div><br>
                  <div><a class="text-secondary mb-2" href="#">offers-2</a></div><br>
                  <div><a class="text-secondary mb-2" href="#">offers-3</a></div><br>
                  <div><a class="text-secondary mb-2" href="#">offers-4</a></div>
                </div>
              </div>
              <div class="col-sm-4 d-flex flex-column align-items-center">
                <div>
                  <div class="text-white mb-3" style="font-size: 20px;">Quick Link</div>
                  <div><a class="text-secondary mb-2" href='contact'>Contact Us</a></div><br>
                  <div><a class="text-secondary mb-2" href='about'>About Us</a></div><br>
                  <div><a class="text-secondary mb-2" href="https://hxk3518.uta.cloud">New & Articles</a></div><br>
                  <div><a class="text-secondary mb-2" href="#">Privacy Policy</a></div>
                </div>
              </div>
              <div class="col-sm-4 d-flex flex-column align-items-center">
                <div>
                  <div class="text-white mb-3" style="font-size: 20px;">+1 235 565 2365</div>
                  <div class="text-secondary mb-2">youremail@gmail.com</div><br>
                  <div class="text-secondary mb-2">123 East 26th Street, Fifth Floor, New York, NY 10011</div>
                </div>
              </div>
            </div>
          </div>
          <hr style="background: #1c2e4c;">
          <div class="d-flex text-secondary justify-content-between align-items-center mb-4">
            <div>Copyright &copy; 2020 All rights reserved | This website is made with <i class="fa fa-heart" style="color: #eb566c;"></i> by <span style="color: #eb566c;">DiazApps</span></div>
            <div class="d-flex">
              <div class="social-badge mr-3">
                <i class="fa fa-facebook fa-lg my-auto"></i>
              </div>
              <div class="social-badge mr-3">
                <i class="fa fa-twitter fa-lg my-auto"></i>
              </div>
              <div class="social-badge mr-3">
                <i class="fa fa-whatsapp fa-lg my-auto"></i>
              </div>
              <div class="social-badge">
                <i class="fa fa-instagram fa-lg my-auto"></i>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
      crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
      crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
      crossorigin="anonymous"></script>
    <script src="public/js/script.js"></script>
  </body>
</html> <?php /**PATH /home/gdn8015/public_html/laravel/resources/views/layouts/app.blade.php ENDPATH**/ ?>