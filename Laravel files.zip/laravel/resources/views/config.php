<?php

$host= "localhost:3306";
$dbUsername= "root";
$dbPassword= "";
$dbName="gdn8015_airrackets";

try{
$pdo=new PDO("mysql:host=$host; dbname=$dbName", $dbUsername, $dbPassword);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
echo"Connection Successful";
}
catch(PDOException $error){
echo $error->getMessage();
}