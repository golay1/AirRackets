<?php
$servername = "localhost:3306";
$username = "hxk3518_wp1";
$password = "airrackets;5";
$dbname = "gdn8015_larauser";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$product_name = $_REQUEST['product_name'];
$type = $_REQUEST['type'];
$image = $_REQUEST['image'];
$description = $_REQUEST['description'];
$blade = $_REQUEST['blade'];
$core = $_REQUEST['core'];
$size = $_REQUEST['size'];
$color = $_REQUEST['color'];
$grip_tape = $_REQUEST['grip_tape'];
$quantity=$_REQUEST['quantity'];
$status=$_REQUEST['status'];
$code=$_REQUEST['code'];
$date_added=$_REQUEST['date_added'];
$price=$_REQUEST['price'];
$store_image = $_REQUEST['store_image'];



  $sql = "INSERT INTO product (product_name, type, image, description,  blade, core, size, color, grip_tape, status, quantity, code, date_added, price)
                        VALUES ('$product_name', '$type', '$image', '$description', '$blade', '$core', '$size', '$color', '$grip_tape', '$status', '$quantity', '$code', '$date_added', '$price')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} 
else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>