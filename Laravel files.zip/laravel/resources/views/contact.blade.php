@extends('layouts.app')

@section('content')
      <div class="text-center text-white title">Contact Us</div>
	  
	  <!--section-->
      <div class="container" style="margin-top: 100px; margin-bottom: 100px;">
        <h2 class="h2 mb-4">Get in Touch</h1>
        <div class="row">
          <div class="col-sm-8">
            <textarea class="form-control mb-4" id="message" rows="8" placeholder="Enter message"></textarea>
            <div class="row mb-4">
              <div class="col-sm-6">
                <input class="form-control" type="text" id="name" placeholder="Enter your name">
              </div>
              <div class="col-sm-6">
                <input class="form-control" type="email" id="email" placeholder="Email">
              </div>
            </div>
            <input class="form-control mb-5" type="text" id="subject" placeholder="Enter subject">
            <button id="send" class="btn btn-outline-danger" style="padding: 10px 30px 10px 30px;">SEND</button>
          </div>
          <div class="col-sm-4">
            <div class="d-flex pl-5 mb-4">
              <i class="fa fa-home text-secondary mr-3" style="font-size: 35px;"></i>
              <div>
                <div class="font-weight-bold">Buttonwood, California</div>
                <div class="text-secondary">Rosemead, CA 91770</div>
              </div>
            </div>
            <div class="d-flex pl-5 mb-4">
              <i class="fa fa-mobile text-secondary mr-3" style="font-size: 45px; padding-left: 6px; padding-right: 6px;"></i>
              <div>
                <div class="font-weight-bold">+1 235 565 2365</div>
                <div class="text-secondary">Mon to Fri 9am to 6pm</div>
              </div>
            </div>
            <div class="d-flex pl-5 mb-4">
              <i class="fa fa-envelope text-secondary mr-3" style="font-size: 30px;"></i>
              <div>
                <div class="font-weight-bold">support@colorlib.com</div>
                <div class="text-secondary">Send us you query anytime!</div>
              </div>
            </div>
          </div>
        </div>
      </div>
	  
	  @endsection