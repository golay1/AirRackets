<!DOCTYPE html>
<html lang="en">
  <head>
	<title>AirRackets - Password Change</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
      crossorigin="anonymous">
    <link rel="stylesheet" href="public/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="public/css/loginstyle.css">
  </head>
    
	<body>
	<?php
	$flag=1;
	$host= "localhost:3306";
$dbUsername= "gdn8015_larauser";
$dbPassword= "airrackets;5";
$dbName="gdn8015_lara1";

try{
$pdo=new PDO("mysql:host=$host; dbname=$dbName", $dbUsername, $dbPassword);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
echo"Connection Successful";
}
catch(PDOException $error){
echo $error->getMessage();
}
$varid = $_GET['varid'];
       $id= $varid;
       if (isset($_POST['password']) && isset($_POST['cpassword'])) {
       	 $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    
  $uppercase = preg_match('@[A-Z]@', $password);
$lowercase = preg_match('@[a-z]@', $password);
$number    = preg_match('@[0-9]@', $password);
$specialChars = preg_match('@[^\w]@', $password);

if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < 8 || strlen($password)  >10) {
     echo '<script>alert("\nPassword should be at between 8-10 characters in length and should include at least one upper case letter, one number, and one special character.")</script>';
    $flag=0;
    exit();
} 
if(!($cpassword== $password)){
echo '<script>alert("\n passwords dont match")</script>';
$flag=0;
}

if($flag==1)
{
 $stmt = $pdo->prepare("UPDATE user SET password=? WHERE id=?");
                            $stmt->execute([$password,$id]); 
                     }
                 }
                 ?>

	  <div class="logo">
         <img src="public/img-proyect/logo200x200.png">
      </div>
	  <div class="main">
        <p class="signinmsg" align="center">You are only one step away from your new password, recover your password now.</p>
        <form class="form1" method="POST" action="">
		@csrf <!-- {{ csrf_field() }} -->
          <input class="password" type="password" align="center" placeholder="Password" name="password" required>
		  <input class="password" type="password" align="center" placeholder="Confirm Password" name="cpassword" required>
		  <button  class="changepass" type="submit" align="center" onclick="validateForm()" > Change password  </button> 
		  <br><br>
          <p class="loginoptions" align="left"><a href='login'>Login</a></p>
		</form>
      </div>
     
    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
      crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
      crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
      crossorigin="anonymous"></script>
    <script src="public/js/script.js"></script>
  </body>
</html>