<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
            crossorigin="anonymous">
        <link rel="stylesheet" href="public/font-awesome-4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="public/css/styles.css">
    </head>
    <body>
        <?php

$host= "localhost:3306";
$dbUsername= "gdn8015_larauser";
$dbPassword= "airrackets;5";
$dbName="gdn8015_lara1";

try{
$pdo=new PDO("mysql:host=$host; dbname=$dbName", $dbUsername, $dbPassword);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
echo"Connection Successful";
}
catch(PDOException $error){
echo $error->getMessage();
}
  $varid = $_GET['varid'];
       echo $varid;
       echo"hello";
	   $id= $varid;
	   if($varid)
	     STATIC $x = 0;

 try
	     {
	         if ((isset($_POST['product_name'])) || (isset($_POST['type'])) || (isset($_POST['image']))|| (isset($_POST['description']))|| (isset($_POST['blade'])) || (isset($_POST['core'])) || (isset($_POST['size'])) || (isset($_POST['color'])) || (isset($_POST['grip_tape'])) || (isset($_POST['quantity'])) || (isset($_POST['status']))|| (isset($_POST['code']))|| (isset($_POST['date_added']))|| (isset($_POST['price']))|| (isset($_POST['store_image'])))
	     {
$product_name = $_POST['product_name'];
$type = $_POST['type'];
$image = $_POST['image'];
$description = $_POST['description'];
$blade = $_POST['blade'];
$core = $_POST['core'];
$size = $_POST['size'];
$color = $_POST['color'];
$grip_tape = $_POST['grip_tape'];
$quantity=$_POST['quantity'];
$status=$_POST['status'];
$code=$_POST['code'];
$date_added=$_POST['date_added'];
$price=$_POST['price'];
$store_image = $_POST['store_image'];

if(!($date_added=""))
{
$date_added=date('Y-m-d');
}
if(!($product_name==""))
{
$pdo->beginTransaction();
  $pdo->exec ("INSERT INTO product (product_name,store_id, type, image, description,  blade, core, size, color, grip_tape, status, quantity, code, date_added, price)
                        VALUES ('$product_name', '$id','$type', '$image', '$description', '$blade', '$core', '$size', '$color', '$grip_tape', '$status', '$quantity', '$code', '$date_added', '$price')");

 $pdo->commit();
echo '<script>alert("Product added successfully")</script>';
}
else
echo '<script>alert("Enter product information")</script>';
}
}

catch (PDOException $e) {
  die($e->getMessage());
}         
    ?>
        <div class="wrapper">

            <nav id="sidebar">
                <div class="sidebar-header">
                    <img class="mr-2" src="public/img-proyect/logo35x35.png">
                    <span class="side-label">AirRackets</span>
                </div>
        
                <ul class="list-unstyled components" style="border: none">
                  <p>
                        <img style="height: 35px; border-radius: 20px;" class="mr-2" src="<?php $qu= $pdo->prepare("select photo FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?>">
                        <span class="side-label"><?php $qu= $pdo->prepare("SELECT name FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?></span>
                    </p>
                    <li class="active">
                        <a href='store-dashboard? varid=<?php echo $varid ?>'><i class="fa fa-tachometer mr-2" aria-hidden="true"></i> <span class="side-label">Dashboard</span></a>
                    </li>
                    <li>
                        <a href='store-product-orders? varid=<?php echo $varid ?>'>
                            <i class="fa fa-trophy mr-2" aria-hidden="true"></i>
                            <span class="side-label">Orders</span>
                            <span class="badge badge-primary ml-auto" style="float: right; background: green;">3</span>
                        </a>
                    </li>
                    <li>
                        <a href="#productsSubMenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <i class="fa fa-group mr-2" aria-hidden="true"></i> 
                            <span class="side-label">Products</span>
                        </a>
                        <ul class="collapse list-unstyled" id="productsSubMenu">
                            <li>
                                <a href='store-list-products-shown? varid=<?php echo $varid ?>'><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">list of products</span></a>
                            </li>
                            <li>
                                <a href='store-load-product? varid=<?php echo $varid ?>'><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">load product</span></a>
                            </li>
                            <li>
                                <a href='store-create-product? varid=<?php echo $varid ?>'><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">create product</span></a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#configSubMenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <i class="fa fa-plus-square-o mr-2" aria-hidden="true"></i> 
                            <span class="side-label">Configurations</span>
                        </a>
                        <ul class="collapse list-unstyled" id="configSubMenu">
                            <li>
                                <a href='store-profile? varid=<?php echo $varid ?>'><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Profile</span></a>
                            </li>
                            <li>
                                <a href='changepass? varid=<?php echo $varid ?>'><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Recover Password</span></a>
                            </li>
                            <li>
                                <a href='lockscreen? varid=<?php echo $varid ?>'><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Lockscreen</span></a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href='login'><i class="fa fa-sign-out mr-2" aria-hidden="true"></i> <span class="side-label">Sign Off</span></a>
                    </li>
                </ul>
            </nav>

            <div id="content" class="d-flex flex-column flex-grow-1">
                <nav id="header" class="navbar navbar-expand-lg navbar-light bg-white" style="border-bottom: 1px solid #e0e0e0;">
                    <div class="container-fluid px-0" style="justify-content: start;">
                        <button type="button" id="sidebarCollapse" class="btn btn-light bg-white" style="border: none; color: #bdbdbd">
                            <i class="fa fa-bars"></i>
                        </button>
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                 <a class="nav-link" href='player-dashboard? varid=<?php echo $varid ?>'>Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href='player-contacts? varid=<?php echo $varid ?>'>Contact</a>
                            </li>
                        </ul>
                        <form class="form-inline ml-3">
                            <div class="header-search" style="position: relative;">
                                <input style="padding-right: 30px; font-size: 14px;" type="text" class="form-control" placeholder="Search">
                                <i class="fa fa-search" aria-hidden="true"></i>
                            </div>
                        </form>
                        <ul class="navbar-nav ml-auto notification-icons">
                            <li class="d-inline-block mr-3 nav-item dropdown" style="position: relative">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="true"><i class="fa fa-comment-o fa-lg"></i></a>
                                <div class="badge badge-danger">3</div>
                                <div class="dropdown-menu p-0 shadow" style="width: 300px; left: -260px;">
                                    <div class="dorpdown-item message-item">
                                        <div class="d-flex">
                                            <img class="message-img align-self-center" src="public/img-proyect/user1-128x128.jpg">
                                            <div class="flex-grow-1">
                                                <div class="message-name">Brad Diesel</div>
                                                <div class="message-tag">Gamer</div>
                                                <div class="message-time text-secondary"><i class="fa fa-clock-o"></i> 4 Hours Ago</div>
                                            </div>
                                            <i class="fa fa-star align-self-start text-danger"></i>
                                        </div>
                                    </div>
                                    <hr class="m-0">
                                    <div class="dorpdown-item message-item">
                                        <div class="d-flex">
                                            <img class="message-img align-self-center" src="public/img-proyect/user8-128x128.jpg">
                                            <div class="flex-grow-1">
                                                <div class="message-name">John Pierce</div>
                                                <div class="message-tag">Gamer</div>
                                                <div class="message-time text-secondary"><i class="fa fa-clock-o"></i> 4 Hours Ago</div>
                                            </div>
                                            <i class="fa fa-star align-self-start text-secondary"></i>
                                        </div>
                                    </div>
                                    <hr class="m-0">
                                    <div class="dorpdown-item message-item">
                                        <div class="d-flex">
                                            <img class="message-img align-self-center" src="public/img-proyect/user3-128x128.jpg">
                                            <div class="flex-grow-1">
                                                <div class="message-name">Nora Silverster</div>
                                                <div class="message-tag">Gamer</div>
                                                <div class="message-time text-secondary"><i class="fa fa-clock-o"></i> 4 Hours Ago</div>
                                            </div>
                                            <i class="fa fa-star align-self-start text-warning"></i>
                                        </div>
                                    </div>
                                    <hr class="m-0">
                                    <div class="dropdown-item message-item text-center" style="font-size: 14px;">
                                        See all messages
                                    </div>
                                </div>
                            </li>
                            <li class="d-inline-block mr-3 nav-item dropdown" style="position: relative">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="true"><i class="fa fa-bell-o fa-lg"></i></a>
                                <div class="badge badge-warning">15</div>
                                <div class="dropdown-menu p-0 shadow" style="width: 300px; left: -260px;">
                                    <div class="dorpdown-item notification-item text-center text-secondary" style="font-size: 14px;">
                                        15 notifications
                                    </div>
                                    <hr class="m-0">
                                    <div class="dorpdown-item notification-item d-flex align-items-center">
                                        <i class="fa fa-envelope mx-2"></i>
                                        <div class="flex-grow-1">4 new messages</div>
                                        <div class="text-secondary" style="font-size: 12px;">3 min</div>
                                    </div>
                                    <hr class="m-0">
                                    <div class="dorpdown-item notification-item d-flex align-items-center">
                                        <i class="fa fa-group mx-2"></i>
                                        <div class="flex-grow-1">8 friend gamer</div>
                                        <div class="text-secondary" style="font-size: 12px;">12 hours</div>
                                    </div>
                                    <hr class="m-0">
                                    <div class="dorpdown-item notification-item d-flex align-items-center">
                                        <i class="fa fa-file mx-2"></i>
                                        <div class="flex-grow-1">3 new requests</div>
                                        <div class="text-secondary" style="font-size: 12px;">2 days</div>
                                    </div>
                                    <hr class="m-0">
                                    <div class="dorpdown-item notification-item text-center" style="font-size: 14px;">
                                        See all notifications
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div id="team-detail" class="flex-grow-1 main-content">
                    <div class="d-flex justify-content-between align-items-center p-3">
                        <h3 class="h3">Create Product</h3>
                        <div>
                            <a href="#">Home</a> / <a href="store-dashboard.html"> </a> / Create Product
                        </div>
                    </div>
                    <div class="card" style="margin: 0 5px 0 5px;">
                        <div class="card-header bg-primary">
                            New Product
                        </div>
                        <form method="POST" action="">
                          @csrf <!-- {{ csrf_field() }} -->
                            <div class="row mx-0 my-2">
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="name" class="font-weight-bold">Name</label>
                                        <input class="form-control" type="text" id="name" name="product_name" placeholder="Enter Name">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="sur-name" class="font-weight-bold">Type</label>
                                        <input class="form-control" type="text" name="type" id="sur-name" placeholder="Enter Type">
                                    </div>
                                </div>
                                <!--input images--> 

                                <div class="col-sm-4">
                                    <label class="font-weight-bold" style="font-size: 14px; margin-bottom: 6px;">Main Image</label>
                                    <div class="custom-file">
                                        <input type="file" id="photo" name="image" class="custom-file-input">
                                        <label class="custom-file-label" for="photo">Choose file</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row mx-0 my-4">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="sur-name" class="font-weight-bold">Description</label>
                                        <textarea class="form-control" rows="3" id="comment" name="description" placeholder="Enter..."></textarea>
                                    </div>
                                </div>
                                <!--Removed the options to enter more images and instead put fields for quantity, code and prize-->
                                <div class="col-sm-3">
                                    <label class="font-weight-bold" style="font-size: 14px; margin-bottom: 6px;">Store Image</label>
                                    <div class="custom-file">
                                        <input type="file" id="photo" name="store_image" class="custom-file-input">
                                        <label class="custom-file-label" for="photo">Choose file</label>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    
                                    <div class="form-group">
                                        <label for="sur-name" class="font-weight-bold">Quantity</label>
                                        <input class="form-control" type="text" name="quantity" id="sur-name" placeholder="Enter...">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label for="sur-name" class="font-weight-bold">Status</label>
                                        <input class="form-control" type="text" name="status" id="sur-name" placeholder="Enter...">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label for="sur-name" class="font-weight-bold">Code</label>
                                        <input class="form-control" type="text" name="code" id="sur-name" placeholder="Enter Type">
                                    </div>
                                </div>
                                <br><br>

                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="profession" class="font-weight-bold">Details</label>
                                        
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label for="profession" class="font-weight-bold">Blade</label>
                                        <input class="form-control" type="text" name="blade" id="profession" placeholder="Enter Blade">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label for="profession" class="font-weight-bold">Core</label>
                                        <input class="form-control" type="text" name="core" id="profession" placeholder="Enter Core">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label for="profession" class="font-weight-bold">Size</label>
                                        <input class="form-control" type="text" name="size" id="profession" placeholder="Enter Size">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label for="profession" class="font-weight-bold">Color</label>
                                        <input class="form-control" type="text" name="color" id="profession" placeholder="Enter Color">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label for="profession" class="font-weight-bold">Grip Tape</label>
                                        <input class="form-control" type="text" id="profession" name="grip_tape" placeholder="Enter Grip tape">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label for="profession" class="font-weight-bold">Price</label>
                                        <input class="form-control" type="text" id="profession" name="price" placeholder="Enter....">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label for="profession" class="font-weight-bold">Date</label>
                                        <input class="form-control" type="date" id="profession" name="date_added" placeholder="Enter....">
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-info"  onlick="validateForm()" name="submit">Submit</button>
                            </form>
                </div>
                <footer class="page-footer" style="border-top: 1px solid #e0e0e0;">
                    <div class="footer-copyright py-3 pl-3" style="color: #9E9E9E; font-weight: bold;">
                        Copyright &copy; 2020 <a style="color: #0091EA;" href="#">DiazApps</a>. All rights reserved.
                    </div>
                </footer>
            </div>
        </div>

        <!-- Scripts -->
        <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
			crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
            crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
            crossorigin="anonymous"></script>
        <script src="public/js/script.js"></script>
    </body>
</html>