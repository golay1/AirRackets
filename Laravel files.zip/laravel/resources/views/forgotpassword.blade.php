<!DOCTYPE html>
<html lang="en">
  <head>
	<title>AirRackets - Password Recovery</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
      crossorigin="anonymous">
    <link rel="stylesheet" href="public/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="public/css/loginstyle.css">
  </head>
    
	<body>
	  <div class="logo">
         <img src="public/img-proyect/logo200x200.png">
      </div>
	  <div class="main" >
        <p class="signinmsg" align="center">You forgot your password? Here you can easily retrieve a new password.</p>
        <form class="form1" method="POST" action="">
				@csrf <!-- {{ csrf_field() }} -->

          <input class="forminput" type="email" align="center" placeholder="Email" name="email" required>
		  <button  value="send" id="send" type="submit" name="submit" class="requestpass" align="center" >Request new password</button>
		  <br><br>
          <p class="loginoptions" align="left"><a href='login'>Login</a></p>
		  <p class="loginoptions" align="left"><a href='register'>Register a new membership</a></p>
		</form>
      </div>
      <?php
      session_start();
	  error_reporting(-1);
ini_set('display_errors', 'On');
set_error_handler("var_dump");
 $host= "localhost:3306";
$dbUsername= "gdn8015_larauser";
$dbPassword= "airrackets;5";
$dbName="gdn8015_lara1";

try{
$pdo=new PDO("mysql:host=$host; dbname=$dbName", $dbUsername, $dbPassword);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
echo"Connection Successful";
}
catch(PDOException $error){
echo $error->getMessage();
}
if(isset($_POST['submit']))
{
      $user= $_POST['email'];
      
if(empty($user)) {
echo "enter mail id";
}
else {
$query = $pdo->prepare("SELECT password FROM user WHERE 
email=? ");
$query->execute([$user]);
$password= $query->fetchColumn();

if($query->rowCount() > 0) {
//mail function for sending mail
$to=$user;
$sender= 'hariganapathy.k@gmail.com';
$subject= "Password";
$headers =  'MIME-Version: 1.0' . "\r\n"; 
$headers .= 'From: ' . "\r\n";
$headers = "MIME-Version: 1.0 .Content-type: text/html; charset=iso-8859-1.";
$txt=" Welcome. Thank you for joining Air Rackets.It is the right app for players to form teams, compete and also make new friends -------- Air Rackets."  ;
$txt=" Hello User ! Your current password is :" .$password;
$status=mail($to,$subject,$txt,$headers);
forward("login");
 } }
}

function forward($url)
{
    if (!headers_sent())
    {    
        header('Location: '.$url);
        exit;
        }
    else
        {  
        echo '<script type="text/javascript">';
        echo 'window.location.href="'.$url.'";';
        echo '</script>';
        echo '<noscript>';
        echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
        echo '</noscript>'; exit;
    }
}
  
      ?>
     
    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
      crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
      crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
      crossorigin="anonymous"></script>
   
  </body>
</html>