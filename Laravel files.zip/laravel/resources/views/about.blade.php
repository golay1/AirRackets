@extends('layouts.app')

@section('content')
	  <div class="text-center text-white title">About Us</div>
	  
	  <!--section1getstarted-->
	  <br><br><br><br><br><br>
	  <div class="row section3">
		<div class="col-sm-2"></div>
		<div class="col-sm-4">
		<br>
			<div class="text-left" style="font-size:20px; color:#eb566c; margin-top:200px;">--- As Application</div>
			<div class="text-left" style="font-size:35px;">We are a tool designed for you</div>
			<div class="text-left" style="font-size:15px;">We only seek to provide the information you need to stay up to date with your sports activities and social gatherings because we know 
				that you need help and AirRackets is here to provide you and that you have it within your reach.<br><br> We will be here evolving according to your needs so that you do not miss any activity.</div>
			<br><br>
			<button id="login" onclick="document.location='login'">GET STARTED</button>
		    </div>
		<div class="col-sm-5">
			<img src="public/img-proyect/3.jpg" style="width:600px">
		</div>
	  </div>	  
	   <?php
	    $host= "localhost:3306";
$dbUsername= "gdn8015_larauser";
$dbPassword= "airrackets;5";
$dbName="gdn8015_lara1";
try{
$pdo=new PDO("mysql:host=$host; dbname=$dbName", $dbUsername, $dbPassword);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $error){
echo $error->getMessage();
}
	   STATIC $x = 0;
    ?>
	  <!--section2stores-->
	  <br><br><br><br><br><br>
	  <div class="row section3">
		<div class="col-sm-2"></div>
		<div class="col-sm-3">
			<div class="text-left" style="font-size:20px; color:#eb566c;"> --- Official Stores</div>
			<div class="text-left" style="font-size:30px;">You will find the best items at the best price</div>
		</div>
		<div class="col-sm-2">
			<img src="<?php $qu= $pdo->prepare("SELECT logo FROM store WHERE store_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?>">
			<img src="<?php $qu= $pdo->prepare("SELECT logo FROM store WHERE store_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?>">
		</div>
		<div class="col-sm-2">
			<img src="<?php $qu= $pdo->prepare("SELECT logo FROM store WHERE store_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?>">
			<img src="<?php $qu= $pdo->prepare("SELECT logo FROM store WHERE store_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?>">
		</div>
		<div class="col-sm-2">
			<img src="<?php $qu= $pdo->prepare("SELECT logo FROM store WHERE store_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?>">
			<img src="<?php $qu= $pdo->prepare("SELECT logo FROM store WHERE store_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?>">
		</div>
	  </div>
	  <br><br><br><br><br><br>
	  
	  <!--section3buttonOurpricing-->
	  <div class="row section3">
		<div class="col-sm-2"></div>
		<div class="col-sm-4">
			<img src="public/img-proyect/racket.png">
		</div>
		<div class="col-sm-5">
		<br>
			<div class="text-left" style="font-size:20px; color:#eb566c; margin-top:200px;"> --- Best articles</div>
			<div class="text-left" style="font-size:30px;">Our pricing</div>
			<div class="text-left" style="font-size:18px;">do not miss this promotion since it is for a limited time only for this week you <br> can enjoy a discount of up to 50%.</div>
			<br><br>
			<button id="login" onclick="document.location='login'">RACKET       BALL</button>
		</div>
	  </div>
	  <br><br><br><br>	  

	  <!--section4gamer-->
	  <div class="row section3">
		<div class="col-sm-2"></div>
		<div class="col-sm-5">
		<br><br><br><br><br>
		  <div class="row">
			<div class="col-sm-2">
				<img src="public/img-proyect/avatar2.png" style="width:100px">
			</div>
			<div class="col-sm-4">
			  <div class="text-left" style="font-size:20px; color:#eb566c;">Luis M Alvarez S</div>
			  <div class="text-left" style="font-size:15px;">Gamer</div>
			</div>
		  </div>
		  <div class="row">
			<div class="text-left" style="font-size:18px;"> do not miss this promotion since it is for a limited time only for this week you <br> can enjoy a discount of up to 50%.</div>
		  </div>
		</div>
		<div class="col-sm-4">
			<img src="public/img-proyect/2.2.png" style="width:400px">
		</div>
	  </div>	
	  <br><br><br><br><br><br>
	  
@endsection