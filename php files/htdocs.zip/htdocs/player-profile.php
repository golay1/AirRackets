<!DOCTYPE html>
<html>
    <head>
		<title>Player Profile</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
            crossorigin="anonymous">
        <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/styles.css">
    </head>
    <body>
     <?php
 $name="";
require_once "config.php";
$varid = $_GET['varid'];
       $id= $varid;
try {
 if (isset($_POST['fname']) || isset($_POST['surname']) || isset($_POST['birthday'])|| isset($_POST['age'])|| isset($_POST['gender'])|| isset($_POST['profession'])|| isset($_POST['email'])|| isset($_POST['tel'])|| isset($_POST['altphone']) ||isset($_POST['address'])|| isset($_POST['country'])|| isset($_POST['city'])|| isset($_POST['beach'])|| isset($_POST['racket'])|| isset($_POST['team']) || isset($_POST['hands'])) {
    $fname = $_POST['fname'];
    $surname=$_POST['surname'];
    $birthday=$_POST['birthday'];
    $age=$_POST['age'];
    $gender= $_POST['gender'];
    $profession=$_POST['profession'];
    $email = $_POST['email'];
    $tel=$_POST['tel'];
    $altphone=$_POST['altphone']; 
    $address=$_POST['address'];
    $country=$_POST['country'];
    $city=$_POST['city'];
    $beach=$_POST['beach'];
    $racket=$_POST['racket'];
    $team=$_POST['team'];
    $hands=$_POST['hands'];
     $flag=1;
                        if(!($birthday==""))
                         {
                             $test_arr  = explode('/', $birthday);
if (count($test_arr) == 3) {
    if (checkdate($test_arr[0], $test_arr[1], $test_arr[2])) {
         $stmt = $pdo->prepare("UPDATE user SET birthday=? WHERE id=?");
                            $stmt->execute([$birthday,$id]);
    } else {
echo '<script>alert("Enter a valid date format (MM/DD/YYYY)")</script>';
    }
} else {

echo '<script>alert("Enter a valid date format (MM/DD/YYYY)")</script>';
}
                            
                         }
   
                        if((!($fname =="")) || (!($surname=="")))
                         {
                            $name= $fname." ". $surname;
                            $stmt = $pdo->prepare("UPDATE user SET name=? WHERE id=?");
                            $stmt->execute([$name,$id]);
                         }
                       
                         if(!($age==""))
                         {
                             $stmt = $pdo->prepare("UPDATE user SET age=? WHERE id=?");
                            $stmt->execute([$age,$id]);
                         }
                         if(!($gender==""))
                         {
                            $stmt = $pdo->prepare("UPDATE user SET gender=? WHERE id=?");
                            $stmt->execute([$gender,$id]);                        
                             }
        if(!($email==""))
         {
                             $email = test_input($_POST["email"]);
    
                     // check if e-mail address is well-formed
                     if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                      $emailErr = "\n*Invalid email format"; 
                      $flag=0;
                     echo '<script>alert("Enter a valid mail format")</script>';
                      }

                         if($flag==1)
                         {
                         	$stmt = $pdo->prepare("UPDATE user SET email=? WHERE id=?");
                            $stmt->execute([$email,$id]);
                         }
        }
                         if(!($tel==""))
                         {
                            if( preg_match('/^[0-9]{10}+$/', $tel)) {
   $stmt = $pdo->prepare("UPDATE user SET tel=? WHERE id=?");
                            $stmt->execute([$tel,$id]);  
}
                             else
                             {
                                 echo '<script>alert("Enter a valid phone number [10 digits]")</script>';
                              }
                                                 
                             }
                         if(!($altphone==""))
                         {
                           if( preg_match('/^[0-9]{10}+$/', $altphone)) {
   $stmt = $pdo->prepare("UPDATE user SET altphone=? WHERE id=?");
                            $stmt->execute([$altphone,$id]);  
}
                             else
                             {
                                 echo '<script>alert("Enter a valid phone number only [10 digit]")</script>';
                              }
                     
                             }
                         if(!($address==""))
                         {
                            $stmt = $pdo->prepare("UPDATE user SET address=? WHERE id=?");
                            $stmt->execute([$address,$id]);                       
                              }
                         if(!($country==""))
                         {
                            $stmt = $pdo->prepare("UPDATE user SET country=? WHERE id=?");
                            $stmt->execute([$country,$id]);                       
                              }
                            
                         if(!($city==""))
                         {
                            $stmt = $pdo->prepare("UPDATE user SET city=? WHERE id=?");
                            $stmt->execute([$city,$id]);                         
                            }
                         if(!($beach==""))
                         {
                            $stmt = $pdo->prepare("UPDATE user SET beach=? WHERE id=?");
                            $stmt->execute([$beach,$id]);                         
                            }
                         if(!($racket==""))
                         {
                            $stmt = $pdo->prepare("UPDATE user SET racket=? WHERE id=?");
                            $stmt->execute([$racket,$id]);                        
                             }
                         if(!($profession==""))
                         {
                            $stmt = $pdo->prepare("UPDATE user SET profession=? WHERE id=?");
                            $stmt->execute([$profession,$id]);                        
                             }
                         if(!($team==""))
                         {
                            $stmt = $pdo->prepare("UPDATE user SET team=? WHERE id=?");
                            $stmt->execute([$team,$id]);                        
                             }
                         if(!($hands==""))
                         {
                            $stmt = $pdo->prepare("UPDATE user SET hands=? WHERE id=?");
                            $stmt->execute([$hands,$id]);
                         }
}
}


catch (PDOException $e) {
  die($e->getMessage());
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

function endsWith($string, $endString) 
{ 
    $len = strlen($endString); 
    if ($len == 0) { 
        return true; 
    } 
    return (substr($string, -$len) === $endString); 
} 





?>
 
 <style>
.error {color: #FF0000;}
</style>

    <?php
	   STATIC $x = 0;
    ?>
	   
        <div class="wrapper">

            <nav id="sidebar">
                <div class="sidebar-header">
                    <img class="mr-2" src="img-proyect/logo35x35.png">
                    <span class="side-label">AirRackets</span>
                </div>
        
                <ul class="list-unstyled components" style="border: none">
                    <p>
                        <img style="height: 35px; border-radius: 20px;" class="mr-2" src="<?php $qu= $pdo->prepare("SELECT photo FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?> ">
                        <span class="side-label"><?php $qu= $pdo->prepare("SELECT name FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?> </span>
                    </p>
                    <li>
                        <a href="player-dashboard.php? varid=<?php echo $varid ?>"><i class="fa fa-tachometer mr-2" aria-hidden="true"></i> <span class="side-label">Dashboard</span></a>
                    </li>
                    <li>
                        <a href="player-contacts.php? varid=<?php echo $varid ?>"><i class="fa fa-address-book mr-2" aria-hidden="true"></i> <span class="side-label">Contacts</span></a>
                    </li>
                    <li>
                        <a href="player-messages.php? varid=<?php echo $varid ?>"><i class="fa fa-comments mr-2" aria-hidden="true"></i> <span class="side-label">Messages</span></a>
                    </li>
                    <li>
                        <a href="player-activities.php? varid=<?php echo $varid ?>">
                            <i class="fa fa-trophy mr-2" aria-hidden="true"></i>
                            <span class="side-label">Activities</span>
                            <span class="badge badge-primary ml-auto" style="float: right; background: #00bcd4;">2</span>
                        </a>
                    </li>
                    <li>
                        <a href="#teamSubMenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <i class="fa fa-group mr-2" aria-hidden="true"></i> 
                            <span class="side-label">Team</span>
                        </a>
                        <ul class="collapse list-unstyled" id="teamSubMenu">
                            <li>
                                <a href="player-my-team.php? varid=<?php echo $varid ?>"><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">See Team</span></a>
                            </li>
                            <li>
                                <a href="player-create-team.php? varid=<?php echo $varid ?>"><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Create Team</span></a>
                            </li>
                            <li>
                                <a href="player-join-team.php? varid=<?php echo $varid ?>"><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Join a Team</span></a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="player-shops.php? varid=<?php echo $varid ?>"><i class="fa fa-shopping-cart mr-2" aria-hidden="true"></i> <span class="side-label">Shops</span></a>
                    </li>
                    <li>
                        <a href="#configSubMenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <i class="fa fa-plus-square-o mr-2" aria-hidden="true"></i> 
                            <span class="side-label">Configurations</span>
                        </a>
                        <ul class="collapse list-unstyled" id="configSubMenu">
                            <li>
                                <a href="player-profile.php? varid=<?php echo $varid ?>"><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Profile</span></a>
                            </li>
                            <li>
                                <a href="changepass.php? varid=<?php echo $varid ?>"><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Recover Password</span></a>
                            </li>
                            <li>
                                <a href="lockscreen.php? varid=<?php echo $varid ?>"><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Screenlock</span></a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="index.php? varid=<?php echo $varid ?>"><i class="fa fa-sign-out mr-2" aria-hidden="true"></i> <span class="side-label">Sign Off</span></a>

                    </li>
                </ul>
            </nav>

            <div id="content" class="d-flex flex-column flex-grow-1">
                <nav id="header" class="navbar navbar-expand-lg navbar-light bg-white" style="border-bottom: 1px solid #e0e0e0;">
                    <div class="container-fluid px-0" style="justify-content: start;">
                        <button type="button" id="sidebarCollapse" class="btn btn-light bg-white" style="border: none; color: #bdbdbd">
                            <i class="fa fa-bars"></i>
                        </button>
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                 <a class="nav-link" href="player-dashboard.php? varid=<?php echo $varid ?>">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="player-dashboard.php? varid=<?php echo $varid ?>">Contact</a>
                            </li>
                        </ul>
                        <form class="form-inline ml-3">
                            <div class="header-search" style="position: relative;">
                                <input style="padding-right: 30px; font-size: 14px;" type="text" class="form-control" placeholder="Search">
                                <i class="fa fa-search" aria-hidden="true"></i>
                            </div>
                        </form>
                        <ul class="navbar-nav ml-auto notification-icons">
                            <li class="d-inline-block mr-3 nav-item dropdown" style="position: relative">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="true"><i class="fa fa-comment-o fa-lg"></i></a>
                                <div class="badge badge-danger">3</div>
                                <div class="dropdown-menu p-0 shadow" style="width: 300px; left: -260px;">
                                    <div class="dorpdown-item message-item">
                                        <div class="d-flex">
                                            <img class="message-img align-self-center" src="img-proyect/user1-128x128.jpg">
                                            <div class="flex-grow-1">
                                                <div class="message-name">Brad Diesel</div>
                                                <div class="message-tag">Gamer</div>
                                                <div class="message-time text-secondary"><i class="fa fa-clock-o"></i> 4 Hours Ago</div>
                                            </div>
                                            <i class="fa fa-star align-self-start text-danger"></i>
                                        </div>
                                    </div>
                                    <hr class="m-0">
                                    <div class="dorpdown-item message-item">
                                        <div class="d-flex">
                                            <img class="message-img align-self-center" src="img-proyect/user8-128x128.jpg">
                                            <div class="flex-grow-1">
                                                <div class="message-name">John Pierce</div>
                                                <div class="message-tag">Gamer</div>
                                                <div class="message-time text-secondary"><i class="fa fa-clock-o"></i> 4 Hours Ago</div>
                                            </div>
                                            <i class="fa fa-star align-self-start text-secondary"></i>
                                        </div>
                                    </div>
                                    <hr class="m-0">
                                    <div class="dorpdown-item message-item">
                                        <div class="d-flex">
                                            <img class="message-img align-self-center" src="img-proyect/user3-128x128.jpg">
                                            <div class="flex-grow-1">
                                                <div class="message-name">Nora Silverster</div>
                                                <div class="message-tag">Gamer</div>
                                                <div class="message-time text-secondary"><i class="fa fa-clock-o"></i> 4 Hours Ago</div>
                                            </div>
                                            <i class="fa fa-star align-self-start text-warning"></i>
                                        </div>
                                    </div>
                                    <hr class="m-0">
                                    <div class="dropdown-item message-item text-center" style="font-size: 14px;">
                                        <a href="player-messages.php? varid=<?php echo $varid ?>">See all messages</a>     
                                    </div>
                                </div>
                            </li>
                            <li class="d-inline-block mr-3 nav-item dropdown" style="position: relative">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="true"><i class="fa fa-bell-o fa-lg"></i></a>
                                <div class="badge badge-warning">15</div>
                                <div class="dropdown-menu p-0 shadow" style="width: 300px; left: -260px;">
                                    <div class="dorpdown-item notification-item text-center text-secondary" style="font-size: 14px;">
                                        15 notifications
                                    </div>
                                    <hr class="m-0">
                                    <div class="dorpdown-item notification-item d-flex align-items-center">
                                        <i class="fa fa-envelope mx-2"></i>
                                        <div class="flex-grow-1">4 new messages</div>
                                        <div class="text-secondary" style="font-size: 12px;">3 min</div>
                                    </div>
                                    <hr class="m-0">
                                    <div class="dorpdown-item notification-item d-flex align-items-center">
                                        <i class="fa fa-group mx-2"></i>
                                        <div class="flex-grow-1">8 friend gamer</div>
                                        <div class="text-secondary" style="font-size: 12px;">12 hours</div>
                                    </div>
                                    <hr class="m-0">
                                    <div class="dorpdown-item notification-item d-flex align-items-center">
                                        <i class="fa fa-file mx-2"></i>
                                        <div class="flex-grow-1">3 new requests</div>
                                        <div class="text-secondary" style="font-size: 12px;">2 days</div>
                                    </div>
                                    <hr class="m-0">
                                    <div class="dorpdown-item notification-item text-center" style="font-size: 14px;">
                                        See all notifications
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div id="contacts" class="flex-grow-1 main-content">
                    <div class="d-flex justify-content-between align-items-center p-3">
                        <h3 class="h3">Profile</h3>
                        <div>
                            <a href="player-dashboard.html">Home</a> / User Profile
                        </div>
                    </div>
                    <div class="row mx-0">
                        <div class="col-sm-3">
                            <div class="card">
                                <div class="card-body border-top border-primary d-flex flex-column align-items-center"
                                    style="border-top-width: 2px !important; padding: 10px 20px 20px 20px;">
                                    <img src="<?php $qu= $pdo->prepare("SELECT photo FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?>" class="user-image">
                                    <div class="user-name text-dark"><?php $qu= $pdo->prepare("SELECT name FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?></div>
                                    <div class="user-tag text-secondary"><?php $qu= $pdo->prepare("SELECT profession FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?></div>
                                    <hr class="splitter w-100">
                                    <div class="d-flex justify-content-between w-100">
                                        <div class="profile-label">Beach</div>
                                        <div class="profile-value"><?php $qu= $pdo->prepare("SELECT beach FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?></div>
                                    </div>
                                    <hr class="splitter w-100">
                                    <div class="d-flex justify-content-between w-100">
                                        <div class="profile-label">Team</div>
                                        <div class="profile-value"><?php $qu= $pdo->prepare("SELECT team FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?></div>
                                    </div>
                                    <hr class="splitter w-100">
                                    <div class="d-flex justify-content-between w-100">
                                        <div class="profile-label">Friends</div>
                                        <div class="profile-value">28</div>
                                    </div>
                                    <hr class="splitter w-100">
                                </div>
                            </div>
                            <div class="card mt-2">
                                <div class="card-header bg-primary text-white">My Team</div>
                                <div class="card-body" style="padding: 20px;">
                                    <div>
                                        <div class="profile-label"><i class="fa fa-star"></i> Captain</div>
                                        <div class="profile-value text-secondary mt-1" style="font-size: 13px;">Miguel Alvarez</div>
                                    </div>
                                    <hr class="splitter">
                                    <div>
                                        <div class="profile-label"><i class="fa fa-heart"></i> Gamer</div>
                                        <div class="profile-value text-secondary mt-1" style="font-size: 13px;">Aura Ramos</div>
                                    </div>
                                    <hr class="splitter">
                                    <div>
                                        <div class="profile-label"><i class="fa fa-heart"></i> Gamer</div>
                                        <div class="profile-value text-secondary mt-1" style="font-size: 13px;">Carlos Rodriguez</div>
                                    </div>
                                    <hr class="splitter">
                                    <div>
                                        <div class="profile-label"><i class="fa fa-heart-o"></i> Gamer</div>
                                        <div class="profile-value text-secondary mt-1" style="font-size: 13px;">Samuel Rodriguez</div>
                                    </div>
                                    <hr class="splitter">
                                    <button class="btn btn-primary w-100" style="margin-top: 10px;">See more</button>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-9 pl-0">
                            <div class="card">
                                <div class="card-header bg-white">
                                    <ul class="nav nav-pills card-header-pills" style="font-size: 14px;" role="tablist" data-tabs="tabs">
                                        <li class="nav-item">
                                            <a href="#information" class="nav-link active" data-toggle="tab">Information</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#moments" class="nav-link" data-toggle="tab">My moments</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#friends" class="nav-link" data-toggle="tab">Friends</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#security" class="nav-link" data-toggle="tab">Security</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="card-body">
                                    <div class="tab-content">
                                        <div id="information" role="tabpanel" class="tab-pane fade in active show">
                                            <div class="card" style="border: none">
                                                <div class="card-body" style="border: none">
                                                    <div class="tab-content">
                                                        <div id="current-info" role="tabpanel" class="tab-pane fade in active show">
                                                            <img src="<?php $qu= $pdo->prepare("SELECT photo FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?>" class="user-image align-self-center">
                                                            <div class="user-name text-dark align-self-center"> <?php $qu= $pdo->prepare("SELECT name FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?>
                                                            </div>
                                                            <hr class="splitter w-100">
                                                            <div class="row mx-0 my-2">
                                                                <div class="col-sm-3">
                                                                    <div class="profile-label"><b>Birthdate</b></div>
                                                                    <div class="profile-value"> <?php $qu= $pdo->prepare("SELECT birthday FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?></div>
                                                                </div>
                                                                <div class="col-sm-3">
                                                                    <div class="profile-label"><b>Age</b></div>
                                                                    <div class="profile-value"><?php $qu= $pdo->prepare("SELECT age FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?></div>
                                                                </div>
                                                                <div class="col-sm-3">
                                                                    <div class="profile-label"><b>Gender</b></div>
                                                                    <div class="profile-value"><?php $qu= $pdo->prepare("SELECT gender FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?></div>
                                                                </div>
                                                                <div class="col-sm-3">
                                                                    <div class="profile-label"><b>Profession</b></div>
                                                                    <div class="profile-value"><?php $qu= $pdo->prepare("SELECT profession FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?></div>
                                                                </div>
                                                            </div>
                                                            <div class="row mx-0 my-2">
                                                                <div class="col-sm-6">
                                                                    <div class="profile-label"><b>Email</b></div>
                                                                    <div class="profile-value"><?php $qu= $pdo->prepare("SELECT email FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?></div>
                                                                </div>
                                                                <div class="col-sm-3">
                                                                    <div class="profile-label"><b>Phone</b></div>
                                                                    <div class="profile-value"><?php $qu= $pdo->prepare("SELECT tel FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?></div>
                                                                </div>
                                                                <div class="col-sm-3">
                                                                    <div class="profile-label"><b>Other Phone</b></div>
                                                                    <div class="profile-value"><?php $qu= $pdo->prepare("SELECT altphone FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?></div>
                                                                </div>
                                                            </div>
                                                            <div class="row mx-0 my-2">
                                                                <div class="col-sm-12">
                                                                    <div class="profile-label"><b>Address</b></div>
                                                                    <div class="profile-value"><?php $qu= $pdo->prepare("SELECT address FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?></div>
                                                                </div>
                                                            </div>
                                                            <div class="row mx-0 my-2">
                                                                <div class="col-sm-4">
                                                                    <div class="profile-label"><b>Country</b></div>
                                                                    <div class="profile-value"><?php $qu= $pdo->prepare("SELECT country FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?></div>
                                                                </div>
                                                                <div class="col-sm-4">
                                                                    <div class="profile-label"><b>City</b></div>
                                                                    <div class="profile-value"><?php $qu= $pdo->prepare("SELECT city FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?></div>
                                                                </div>
                                                                <div class="col-sm-4">
                                                                    <div class="profile-label"><b>Beach where you play</b></div>
                                                                    <div class="profile-value"><?php $qu= $pdo->prepare("SELECT beach FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?></div>
                                                                </div>
                                                            </div>
                                                            <div class="row mx-0 my-2">
                                                                <div class="col-sm-4">
                                                                    <div class="profile-label"><b>Racket you wear</b></div>
                                                                    <div class="profile-value"><?php $qu= $pdo->prepare("SELECT racket FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?></div>
                                                                </div>
                                                                <div class="col-sm-4">
                                                                    <div class="profile-label"><b>Team name</b></div>
                                                                    <div class="profile-value"><?php $qu= $pdo->prepare("SELECT team FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?></div>
                                                                </div>
                                                                <div class="col-sm-4">
                                                                    <div class="profile-label"><b>Which hand do you use?</b></div>
                                                                    <div class="profile-value"><?php $qu= $pdo->prepare("SELECT hands FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div id="update-info" role="tabpanel" class="tab-pane fade in" >
                                                        <form method="POST">
                                                            <div class="row mx-0 my-2">
                                                                <div class="col-sm-4">
                                                                    <div class="form-group">
                                                                        <label for="name" class="font-weight-bold">Name</label>
                                                                        <input class="form-control" type="text" id="name" placeholder="Enter ..." name="fname" >
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-4">
                                                                    <div class="form-group">
                                                                        <label for="sur-name" class="font-weight-bold">Surname</label>
                                                                        <input class="form-control" type="text" id="sur-name" placeholder="Enter ..."name="surname" >
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-4">
                                                                    <label class="font-weight-bold" style="font-size: 14px; margin-bottom: 6px;">Photo</label>
                                                                    <div class="custom-file">
                                                                        <input type="file" id="photo" class="custom-file-input" name="photo">
                                                                        <label class="custom-file-label" for="photo">Choose file</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row mx-0 my-2">
                                                                <div class="col-sm-4">
                                                                    <div class="form-group">
                                                                        <label for="birthdate" class="font-weight-bold" >Birthdate</label>
                                                                        <div class="input-group mb-3">
                                                                            <div class="input-group-prepend">
                                                                                <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                                                            </div>
                                                                            <input id="birthdate" class="form-control" type="date" name="birthday" >
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-2">
                                                                    <div class="form-group">
                                                                        <label for="age" class="font-weight-bold">Age</label>
                                                                        <input class="form-control" type="number" id="age" placeholder="Enter ..." name="age" >
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-2">
                                                                    <div class="form-group">
                                                                        <label for="gender" class="font-weight-bold">Gender</label>
                                                                        <select class="form-control" id="gender" style="height: 35px;" name="gender" required>
                                                                            <option>Male</option>
                                                                            <option>Female</option>
                                                                            <option>Other</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-4">
                                                                    <div class="form-group">
                                                                        <label for="profession" class="font-weight-bold">Profession</label>
                                                                        <input class="form-control" type="text" id="profession" placeholder="Enter ..." name="profession" >
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row mx-0 my-2">
                                                                <div class="col-sm-6">
                                                                    <div class="form-group">
                                                                        <label for="email" class="font-weight-bold">Email</label>
                                                                        <div class="input-group mb-3">
                                                                            <div class="input-group-prepend">
                                                                                <span class="input-group-text"><i class="fa fa-envelope"></i></span>
                                                                            </div>
                                                                            <input id="email" class="form-control" type="email" placeholder="Email" name="email" >
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-3">
                                                                    <div class="form-group">
                                                                        <label for="phone" class="font-weight-bold">Phone</label>
                                                                        <div class="input-group mb-3">
                                                                            <div class="input-group-prepend">
                                                                                <span class="input-group-text"><i class="fa fa-phone"></i></span>
                                                                            </div>
                                                                            <input id="phone" class="form-control" type="tel" name="tel">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-3">
                                                                    <div class="form-group">
                                                                        <label for="other-phone" class="font-weight-bold">Other Phone</label>
                                                                        <div class="input-group mb-3">
                                                                            <div class="input-group-prepend">
                                                                                <span class="input-group-text"><i class="fa fa-phone"></i></span>
                                                                            </div>
                                                                            <input id="other-phone" class="form-control" type="tel" name="altphone">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row mx-0 my-2">
                                                                <div class="col-sm-12">
                                                                    <div class="form-group">
                                                                        <label for="address" class="font-weight-bold">Address</label>
                                                                        <input class="form-control" type="text" id="address" placeholder="Enter ..." name="address">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row mx-0 my-2">
                                                                <div class="col-sm-4">
                                                                    <div class="form-group">
                                                                        <label for="country" class="font-weight-bold">Country</label>
                                                                        <input class="form-control" type="text" id="country" placeholder="Enter ..." name="country">
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-4">
                                                                    <div class="form-group">
                                                                        <label for="city" class="font-weight-bold">City</label>
                                                                        <input class="form-control" type="text" id="city" placeholder="Enter ..." name="city">
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-4">
                                                                    <div class="form-group">
                                                                        <label for="beach" class="font-weight-bold">Beach where you plays</label>
                                                                        <input class="form-control" type="text" id="beach" placeholder="Enter ..." name="beach">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row mx-0 my-2">
                                                                <div class="col-sm-4">
                                                                    <div class="form-group">
                                                                        <label for="racket" class="font-weight-bold">Racket you wear</label>
                                                                        <input class="form-control" type="text" id="racket" placeholder="Enter ..." name="racket">
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-4">
                                                                    <div class="form-group">
                                                                        <label for="team-name" class="font-weight-bold">Team name</label>
                                                                        <input class="form-control" type="text" id="team-name" placeholder="Enter ..." name="team">
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-4">
                                                                    <div class="form-group">
                                                                        <label for="hand" class="font-weight-bold">Which hand do you use?</label>
                                                                        <input class="form-control" type="text" id="hand" placeholder="Enter ..." name="hands">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <hr class="splitter">
                                                            <button type="submit" name="submit"  class="btn btn-secondary" style="float: right;" onclick="validateForm()">To Update </button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-footer" style="border: none">
                                                    <ul class="nav nav-pills card-footer-pills justify-content-end" style="font-size: 14px;" role="tablist" data-tabs="tabs">
                                                        <li class="nav-item">
                                                            <a href="#current-info" class="nav-link active" data-toggle="tab">Current Data</a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="#update-info" class="nav-link" data-toggle="tab">Update Data</a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            </form>
                                        </div>
                                        <div id="moments" role="tabpanel" class="tab-pane fade in">
                                            <div class="d-flex mb-3">
                                                <img src="<?php $qu= $pdo->prepare("SELECT photo FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?>" class="post-user-image">
                                                <div class="flex-grow-1">
                                                    <div class="post-user-name text-primary font-weight-bold"><?php $qu= $pdo->prepare("SELECT name FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?></div>
                                                    <div class="post-time text-secondary">Welcome</div>
                                                </div>
                                                <div class="align-self-start">
                                                    <i class="fa fa-camera fa-lg text-secondary"></i>
                                                </div>
                                            </div>
                                            <hr class="splitter">
                                            <div class="my-3">
                                                <div class="d-flex mb-3">
                                                    <img src="<?php $qu= $pdo->prepare("SELECT photo FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?>" class="post-user-image">
                                                    <div class="flex-grow-1">
                                                        <div class="post-user-name text-primary font-weight-bold"><?php $qu= $pdo->prepare("SELECT name FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?></div>
                                                        <div class="post-time text-secondary">Posted 5 photos - 5 days ago</div>
                                                    </div>
                                                </div>
                                                <div class="row mx-0 align-items-center mb-3">
                                                    <div class="col-sm-6 p-0">
                                                        <img src="img-proyect/Playa-Parguito.jpg" class="post-image">
                                                    </div>
                                                    <div class="col-sm-6 p-0">
                                                        <div class="row mx-0 p-0">
                                                            <div class="col-sm-6 p-0">
                                                                <img src="img-proyect/palas-playa.jpg" class="post-image">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="post-options d-flex text-secondary" style="margin-left: 5px; margin-right: 5px;">
                                                    <div class="mr-2"><i class="fa fa-share"></i> Share</div>
                                                    <div><i class="fa fa-thumbs-o-up"></i> Like</div>
                                                    <div class="ml-auto"><i class="fa fa-comments-o"></i> Comments (5)</div>
                                                </div>
                                                <div class="my-3" style="padding: 10px; background: #f8f9fa;">
                                                    <div class="d-flex mb-3">
                                                        <img src="img-proyect/user3-128x128.jpg" class="comment-user-image">
                                                        <div class="flex-grow-1">
                                                            <div class="comment-user-name font-weight-bold">Maria Gonzales</div>
                                                            <div class="comment-text text-secondary">It is a long established fact that a reader will be distracted by a readable content of the page when looking at its layout</div>
                                                        </div>
                                                        <div class="align-self-start comment-time">8:03 PM Today</div>
                                                    </div>
                                                    <hr class="splitter">
                                                    <div class="d-flex mb-3">
                                                        <img src="img-proyect/user4-128x128.jpg" class="comment-user-image">
                                                        <div class="flex-grow-1">
                                                            <div class="comment-user-name font-weight-bold">Luna Stark</div>
                                                            <div class="comment-text text-secondary">It is a long established fact that a reader will be distracted by a readable content of the page when looking at its layout</div>
                                                        </div>
                                                        <div class="align-self-start comment-time">8:03 PM Today</div>
                                                    </div>
                                                    <div class="d-flex mt-4">
                                                        <img src="<?php $qu= $pdo->prepare("SELECT photo FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?>" class="comment-user-image">
                                                        <input class="form-control" style="font-size: 12px;" type="text" placeholder="Press Enter to post comment">
                                                    </div>
                                                </div>
                                            </div>
                                            <hr class="splitter">
                                            <div class="my-3">
                                                <div class="d-flex mb-3">
                                                    <img src="<?php $qu= $pdo->prepare("SELECT photo FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?>" class="post-user-image">
                                                    <div class="flex-grow-1">
                                                        <div class="post-user-name text-primary font-weight-bold"><?php $qu= $pdo->prepare("SELECT name FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?></div>
                                                        <div class="post-time text-secondary">Posted 2 photos - 15 days ago</div>
                                                    </div>
                                                </div>
                                                <div class="row mx-0 align-items-center mb-3">
                                                    <div class="col-sm-6 p-0">
                                                        <img src="img-proyect/palas-talamanca-ibiza-welcometoibiza.jpg" class="post-image">
                                                    </div>
                                                    <div class="col-sm-6 p-0">
                                                        <img src="img-proyect/unnamed.jpg" class="post-image">
                                                    </div>
                                                </div>
                                                <div class="post-options d-flex text-secondary" style="margin-left: 5px; margin-right: 5px;">
                                                    <div class="mr-2"><i class="fa fa-share"></i> Share</div>
                                                    <div><i class="fa fa-thumbs-o-up"></i> Like</div>
                                                    <div class="ml-auto"><i class="fa fa-comments-o"></i> Comments (9)</div>
                                                </div>
                                                <div class="my-3" style="padding: 10px; background: #f8f9fa;">
                                                    <div class="d-flex mb-3">
                                                        <img src="img-proyect/user3-128x128.jpg" class="comment-user-image">
                                                        <div class="flex-grow-1">
                                                            <div class="comment-user-name font-weight-bold">Maria Gonzales</div>
                                                            <div class="comment-text text-secondary">It is a long established fact that a reader will be distracted by a readable content of the page when looking at its layout</div>
                                                        </div>
                                                        <div class="align-self-start comment-time">8:03 PM Today</div>
                                                    </div>
                                                    <hr class="splitter">
                                                    <div class="d-flex mb-3">
                                                        <img src="img-proyect/user4-128x128.jpg" class="comment-user-image">
                                                        <div class="flex-grow-1">
                                                            <div class="comment-user-name font-weight-bold">Luna Stark</div>
                                                            <div class="comment-text text-secondary">It is a long established fact that a reader will be distracted by a readable content of the page when looking at its layout</div>
                                                        </div>
                                                        <div class="align-self-start comment-time">8:03 PM Today</div>
                                                    </div>
                                                    <div class="d-flex mt-4">
                                                        <img src="<?php $qu= $pdo->prepare("SELECT photo FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?>" class="comment-user-image">
                                                        <input class="form-control" style="font-size: 12px;" type="text" placeholder="Press Enter to post comment">
                                                    </div>
                                                </div>
                                            </div>
                                            <hr class="splitter">
                                            <div class="mt-3">
                                                <div class="d-flex mb-3">
                                                    <img src="<?php $qu= $pdo->prepare("SELECT photo FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?>" class="post-user-image">
                                                    <div class="flex-grow-1">
                                                        <div class="post-user-name text-primary font-weight-bold"><?php $qu= $pdo->prepare("SELECT name FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?></div>
                                                        <div class="post-time text-secondary">Posted 5 photos - 5 days ago</div>
                                                    </div>
                                                </div>
                                                <div class="row mx-0 align-items-center mb-3">
                                                    <div class="col-sm-6 p-0">
                                                        <div class="row mx-0 p-0">
                                                            <div class="col-sm-6 p-0">
                                                                <img src="img-proyect/palas-talamanca-ibiza-welcometoibiza.jpg" class="post-image">
                                                            </div>
                                                            <div class="col-sm-6 p-0">
                                                                <img src="img-proyect/unnamed.jpg" class="post-image">
                                                            </div>
                                                            <div class="col-sm-6 p-0">
                                                                <img src="img-proyect/linchan-pareja.jpg" class="post-image">
                                                            </div>  
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="post-options d-flex text-secondary" style="margin-left: 5px; margin-right: 5px;">
                                                    <div class="mr-2"><i class="fa fa-share"></i> Share</div>
                                                    <div><i class="fa fa-thumbs-o-up"></i> Like</div>
                                                    <div class="ml-auto"><i class="fa fa-comments-o"></i> Comments (5)</div>
                                                </div>
                                                <div class="mt-3" style="padding: 10px; background: #f8f9fa;">
                                                    <div class="d-flex mb-3">
                                                        <img src="img-proyect/user3-128x128.jpg" class="comment-user-image">
                                                        <div class="flex-grow-1">
                                                            <div class="comment-user-name font-weight-bold">Maria Gonzales</div>
                                                            <div class="comment-text text-secondary">It is a long established fact that a reader will be distracted by a readable content of the page when looking at its layout</div>
                                                        </div>
                                                        <div class="align-self-start comment-time">8:03 PM Today</div>
                                                    </div>
                                                    <hr class="splitter">
                                                    <div class="d-flex mb-3">
                                                        <img src="img-proyect/user4-128x128.jpg" class="comment-user-image">
                                                        <div class="flex-grow-1">
                                                            <div class="comment-user-name font-weight-bold">Luna Stark</div>
                                                            <div class="comment-text text-secondary">It is a long established fact that a reader will be distracted by a readable content of the page when looking at its layout</div>
                                                        </div>
                                                        <div class="align-self-start comment-time">8:03 PM Today</div>
                                                    </div>
                                                    <div class="d-flex mt-4">
                                                        <img src="<?php $qu= $pdo->prepare("SELECT photo FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();
                                                            ?>
                                                            <?php echo $disp; ?>" class="comment-user-image">
                                                        <input class="form-control" style="font-size: 12px;" type="text" placeholder="Press Enter to post comment">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="friends" role="tabpanel" class="tab-pane fade in">
                                            <div class="card" style="border: none;">
                                                <div class="card-header bg-white">
                                                    Latest members
                                                    <div class="badge badge-info" style="float: right; margin-top: 3px; margin-right: -5px;">8 new members</div>
                                                </div>
                                                <div class="card-body" style="padding: 10px">
                                                    <div class="row mx-0">
                                                        <div class="col-sm-3 d-flex flex-column align-items-center px-0 friend">
                                                            <img class="friend-image" src="img-proyect/user1-128x128.jpg">
                                                            <div class="friend-name">Alexander Pirez</div>
                                                            <div class="friend-time">Today</div>
                                                        </div>
                                                        <div class="col-sm-3 d-flex flex-column align-items-center px-0 friend">
                                                            <img class="friend-image" src="img-proyect/user8-128x128.jpg">
                                                            <div class="friend-name">Norman</div>
                                                            <div class="friend-time">Yesterday</div>
                                                        </div>
                                                        <div class="col-sm-3 d-flex flex-column align-items-center px-0 friend">
                                                            <img class="friend-image" src="img-proyect/user7-128x128.jpg">
                                                            <div class="friend-name">Jane</div>
                                                            <div class="friend-time">12 Jan</div>
                                                        </div>
                                                        <div class="col-sm-3 d-flex flex-column align-items-center px-0 friend">
                                                            <img class="friend-image" src="img-proyect/user6-128x128.jpg">
                                                            <div class="friend-name">John</div>
                                                            <div class="friend-time">12 Jan</div>
                                                        </div>
                                                        <div class="col-sm-3 d-flex flex-column align-items-center px-0 friend">
                                                            <img class="friend-image" src="img-proyect/user2-128x128.jpg">
                                                            <div class="friend-name">Alexander</div>
                                                            <div class="friend-time">13 Jan</div>
                                                        </div>
                                                        <div class="col-sm-3 d-flex flex-column align-items-center px-0 friend">
                                                            <img class="friend-image" src="img-proyect/user5-128x128.jpg">
                                                            <div class="friend-name">Sarah</div>
                                                            <div class="friend-time">14 Jan</div>
                                                        </div>
                                                        <div class="col-sm-3 d-flex flex-column align-items-center px-0 friend">
                                                            <img class="friend-image" src="img-proyect/user4-128x128.jpg">
                                                            <div class="friend-name">Nora</div>
                                                            <div class="friend-time">15 Jan</div>
                                                        </div>
                                                        <div class="col-sm-3 d-flex flex-column align-items-center px-0 friend">
                                                            <img class="friend-image" src="img-proyect/user3-128x128.jpg">
                                                            <div class="friend-name">Nadia</div>
                                                            <div class="friend-time">15 Jan</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-footer text-center" style="border-top: none;">
                                                    <a href="#">View all friends</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="security" role="tabpanel" class="tab-pane fade in">
                                            <div class="card" style="border: none">
                                                <div class="card-body">
                                                    <div class="row mx-0 mb-3 align-items-center security-input">
                                                        <div class="col-sm-2 p-0">
                                                            <label for="current-passowrd" class="font-weight-bold mb-0">Current password</label>
                                                        </div>
                                                        <div class="col-sm-10 p-0">
                                                            <input class="form-control" type="password" id="current-passowrd" placeholder="Current password">
                                                        </div>
                                                    </div>
                                                    <div class="row mx-0 mb-3 align-items-center security-input">
                                                        <div class="col-sm-2 p-0">
                                                            <label for="new-passowrd" class="font-weight-bold mb-0">New password</label>
                                                        </div>
                                                        <div class="col-sm-10 p-0">
                                                            <input class="form-control" type="password" id="new-passowrd" placeholder="New password">
                                                        </div>
                                                    </div>
                                                    <div class="row mx-0 align-items-center security-input">
                                                        <div class="col-sm-2 p-0">
                                                            <label for="confirm-passowrd" class="font-weight-bold mb-0">Confirm password</label>
                                                        </div>
                                                        <div class="col-sm-10 p-0">
                                                            <input class="form-control" type="password" id="confirm-passowrd" placeholder="Confirm password">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-footer" style="border-top: none;">
                                                    <button class="btn btn-info">To Update</button>
                                                    <button class="btn" style="float: right">Cancel</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                 <footer class="page-footer" style="border-top: 1px solid #e0e0e0;">
                    <div class="footer-copyright py-3 pl-3" style="color: #9E9E9E; font-weight: bold;">
                        Copyright &copy; 2020 <a style="color: #0091EA;" href="#">DiazApps</a>. All rights reserved.
                    </div>
                </footer>
            </div>
        </div>
               <!-- Scripts -->
        <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
			crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
            crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
            crossorigin="anonymous"></script>
        <script src="js/script.js"></script>
    </body>
</html>