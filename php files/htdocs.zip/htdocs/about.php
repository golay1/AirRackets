<!DOCTYPE html>
<html lang="en">
  <head>
	<title>AirRackets - About Us</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
      crossorigin="anonymous">
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/homestyle.css">
  </head>
  <body>
    <?php
       require_once "config.php";
	   STATIC $x = 0;
    ?>
	
	<div id="main" class="d-flex flex-column">
	
	  <!--header-->
      <nav id="header" class="navbar navbar-expand-lg" style="background: #020230">
        <div class="container-fluid px-0">
          <img src="img-proyect/logo100x100.png" class="ml-5">
          <ul class="navbar-nav ml-auto mr-5">
            <li class="nav-item">
              <a class="nav-link text-white" href="index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="about.php">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="store.php">Store</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="blog.php">Blog</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="contact.php">Contact</a>
            </li>
          </ul>
          <button id="login" class="mx-5" onclick="document.location='login.php'">LOGIN</button>
        </div>
      </nav>
	  <div class="text-center text-white title">About Us</div
	  
	  <!--section1getstarted-->
	  <br><br><br><br><br><br>
	  <div class="row section3">
		<div class="col-sm-2"></div>
		<div class="col-sm-4">
		<br>
			<div class="text-left" style="font-size:20px; color:#eb566c; margin-top:200px;">--- As Application</div>
			<div class="text-left" style="font-size:35px;">We are a tool designed for you</div>
			<div class="text-left" style="font-size:15px;">We only seek to provide the information you need to stay up to date with your sports activities and social gatherings because we know 
				that you need help and AirRackets is here to provide you and that you have it within your reach.<br><br> We will be here evolving according to your needs so that you do not miss any activity.</div>
			<br><br>
			<button id="login" onclick="document.location='login.php'">GET STARTED</button>
		</div>
		<div class="col-sm-5">
			<img src="img-proyect/3.jpg" style="width:600px">
		</div>
	  </div>	  
	  
	  <!--section2stores-->
	  <br><br><br><br><br><br>
	  <div class="row section3">
		<div class="col-sm-2"></div>
		<div class="col-sm-3">
			<div class="text-left" style="font-size:20px; color:#eb566c;"> --- Official Stores</div>
			<div class="text-left" style="font-size:30px;">You will find the best items at the best price</div>
		</div>
		<div class="col-sm-2">
			<img src="<?php $qu= $pdo->prepare("SELECT logo FROM store WHERE store_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?>">
			<img src="<?php $qu= $pdo->prepare("SELECT logo FROM store WHERE store_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?>">
		</div>
		<div class="col-sm-2">
			<img src="<?php $qu= $pdo->prepare("SELECT logo FROM store WHERE store_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?>">
			<img src="<?php $qu= $pdo->prepare("SELECT logo FROM store WHERE store_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?>">
		</div>
		<div class="col-sm-2">
			<img src="<?php $qu= $pdo->prepare("SELECT logo FROM store WHERE store_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?>">
			<img src="<?php $qu= $pdo->prepare("SELECT logo FROM store WHERE store_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?><?php echo $disp; ?>">
		</div>
	  </div>
	  <br><br><br><br><br><br>
	  
	  <!--section3buttonOurpricing-->
	  <div class="row section3">
		<div class="col-sm-2"></div>
		<div class="col-sm-4">
			<img src="img-proyect/productos/racket.png">
		</div>
		<div class="col-sm-5">
		<br>
			<div class="text-left" style="font-size:20px; color:#eb566c; margin-top:200px;"> --- Best articles</div>
			<div class="text-left" style="font-size:30px;">Our pricing</div>
			<div class="text-left" style="font-size:18px;">do not miss this promotion since it is for a limited time only for this week you <br> can enjoy a discount of up to 50%.</div>
			<br><br>
			<button id="login" onclick="document.location='#'">RACKET       BALL</button>
		</div>
	  </div>
	  <br><br><br><br>	  

	  <!--section4gamer-->
	  <div class="row section3">
		<div class="col-sm-2"></div>
		<div class="col-sm-5">
		<br><br><br><br><br>
		  <div class="row">
			<div class="col-sm-2">
				<img src="img-proyect/avatar2.png" style="width:100px">
			</div>
			<div class="col-sm-4">
			  <div class="text-left" style="font-size:20px; color:#eb566c;">Luis M Alvarez S</div>
			  <div class="text-left" style="font-size:15px;">Gamer</div>
			</div>
		  </div>
		  <div class="row">
			<div class="text-left" style="font-size:18px;"> do not miss this promotion since it is for a limited time only for this week you <br> can enjoy a discount of up to 50%.</div>
		  </div>
		</div>
		<div class="col-sm-4">
			<img src="img-proyect/2.2.png" style="width:400px">
		</div>
	  </div>	
	  <br><br><br><br><br><br>
	  
	  <!--footer-->
      <footer style="background: #010e22; padding-top: 200px;">
        <div class="container">
          <div class="d-flex align-items-center" style="margin-bottom: 100px;">
            <img src="img-proyect/logo200x200.png" class="mr-5">
            <div class="row mx-0 flex-grow-1">
              <div class="col-sm-4 d-flex flex-column align-items-center">
                <div>
                  <div class="text-white mb-3" style="font-size: 20px;">All Offers</div>
                  <div><a class="text-secondary mb-2" href="#">offers-1</a></div><br>
                  <div><a class="text-secondary mb-2" href="#">offers-2</a></div><br>
                  <div><a class="text-secondary mb-2" href="#">offers-3</a></div><br>
                  <div><a class="text-secondary mb-2" href="#">offers-4</a></div>
                </div>
              </div>
              <div class="col-sm-4 d-flex flex-column align-items-center">
                <div>
                  <div class="text-white mb-3" style="font-size: 20px;">Quick Link</div>
                  <div><a class="text-secondary mb-2" href="contact.php">Contact Us</a></div><br>
                  <div><a class="text-secondary mb-2" href="about.php">About Us</a></div><br>
                  <div><a class="text-secondary mb-2" href="blog.php">New & Articles</a></div><br>
                  <div><a class="text-secondary mb-2" href="#">Privacy Policy</a></div>
                </div>
              </div>
              <div class="col-sm-4 d-flex flex-column align-items-center">
                <div>
                  <div class="text-white mb-3" style="font-size: 20px;">+1 235 565 2365</div>
                  <div class="text-secondary mb-2">youremail@gmail.com</div><br>
                  <div class="text-secondary mb-2">123 East 26th Street, Fifth Floor, New York, NY 10011</div>
                </div>
              </div>
            </div>
          </div>
          <hr style="background: #1c2e4c;">
          <div class="d-flex text-secondary justify-content-between align-items-center mb-4">
            <div>Copyright &copy; 2020 All rights reserved | This website is made with <i class="fa fa-heart" style="color: #eb566c;"></i> by <span style="color: #eb566c;">DiazApps</span></div>
            <div class="d-flex">
              <div class="social-badge mr-3">
                <i class="fa fa-facebook fa-lg my-auto"></i>
              </div>
              <div class="social-badge mr-3">
                <i class="fa fa-twitter fa-lg my-auto"></i>
              </div>
              <div class="social-badge mr-3">
                <i class="fa fa-whatsapp fa-lg my-auto"></i>
              </div>
              <div class="social-badge">
                <i class="fa fa-instagram fa-lg my-auto"></i>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
      crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
      crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
      crossorigin="anonymous"></script>
    <script src="js/script.js"></script>
  </body>
</html>