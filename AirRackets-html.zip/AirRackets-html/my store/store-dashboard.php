<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
            crossorigin="anonymous">
        <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/styles.css">
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Year', 'Sales', 'Expenses'],
          ['2004',  1000,      400],
          ['2005',  1170,      460],
          ['2006',  660,       1120],
          ['2007',  1030,      540]
        ]);

        var options = {
          title: 'Company Performance',
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
    </script>


    </head>
    <body>
    <?php
       require_once "config.php";
       $varid = $_GET['varid'];
       echo $varid;
       echo"hello";
	   $id= $varid;
	   if($varid)
	     STATIC $x = 0;
    ?>

        <div class="wrapper">

            <nav id="sidebar">
                <div class="sidebar-header">
                    <img class="mr-2" src="img-proyect/logo35x35.png">
                    <span class="side-label">AirRackets</span>
                </div>
        
                <ul class="list-unstyled components" style="border: none">
                    <p>
                        <img style="height: 35px; border-radius: 20px;" class="mr-2" src="<?php $qu= $pdo->prepare("select photo FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?>">
                        <span class="side-label"><?php $qu= $pdo->prepare("SELECT name FROM user WHERE id=?");
                                                            $qu->execute([$id]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?></span>
                    </p>
                    <li class="active">
                        <a href="store-dashboard.php? varid=<?php echo $varid ?>"><i class="fa fa-tachometer mr-2" aria-hidden="true"></i> <span class="side-label">Dashboard</span></a>
                    </li>
                    <li>
                        <a href="store-product-orders.php? varid=<?php echo $varid ?>">
                            <i class="fa fa-trophy mr-2" aria-hidden="true"></i>
                            <span class="side-label">Orders</span>
                            <span class="badge badge-primary ml-auto" style="float: right; background: green;">3</span>
                        </a>
                    </li>
                    <li>
                        <a href="#productsSubMenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <i class="fa fa-group mr-2" aria-hidden="true"></i> 
                            <span class="side-label">Products</span>
                        </a>
                        <ul class="collapse list-unstyled" id="productsSubMenu">
                            <li>
                                <a href="store-list-products-shown.php? varid=<?php echo $varid ?>"><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">list of products</span></a>
                            </li>
                            <li>
                                <a href="store-load-product.html"><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">load product</span></a>
                            </li>
                            <li>
                                <a href="store-create-product.php? varid=<?php echo $varid ?>"><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">create product</span></a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#configSubMenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <i class="fa fa-plus-square-o mr-2" aria-hidden="true"></i> 
                            <span class="side-label">Configurations</span>
                        </a>
                        <ul class="collapse list-unstyled" id="configSubMenu">
                            <li>
                                <a href="store-profile.php? varid=<?php echo $varid ?>"><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Profile</span></a>
                            </li>
                            <li>
                                <a href="forgotpass.php"><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Recover Password</span></a>
                            </li>
                            <li>
                                <a href="lockscreen.php"><i class="fa fa-circle-thin mr-2" aria-hidden="true"></i> <span class="side-label">Lockscreen</span></a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="login.php"><i class="fa fa-sign-out mr-2" aria-hidden="true"></i> <span class="side-label">Sign Off</span></a>
                    </li>
                </ul>
            </nav>

            <div id="content" class="d-flex flex-column flex-grow-1">
                <nav id="header" class="navbar navbar-expand-lg navbar-light bg-white" style="border-bottom: 1px solid #e0e0e0;">
                    <div class="container-fluid px-0" style="justify-content: start;">
                        <button type="button" id="sidebarCollapse" class="btn btn-light bg-white" style="border: none; color: #bdbdbd">
                            <i class="fa fa-bars"></i>
                        </button>
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="#">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="contact.php">Contact</a>
                            </li>
                        </ul>
                        <form class="form-inline ml-3">
                            <div class="header-search" style="position: relative;">
                                <input style="padding-right: 30px; font-size: 14px;" type="text" class="form-control" placeholder="Search">
                                <i class="fa fa-search" aria-hidden="true"></i>
                            </div>
                        </form>
                        <div class="notification-icons ml-auto">
                            <div class="d-inline-block mr-3" style="position: relative">
                                <i class="fa fa-comment-o fa-lg"></i>
                                <div class="badge badge-danger">3</div>
                            </div>
                            <div class="d-inline mr-3" style="position: relative">
                                <i class="fa fa-bell-o fa-lg"></i>
                                <div class="badge badge-warning">15</div>
                            </div>
                        </div>
                    </div>
                </nav>
                <div id="dashboard" class="flex-grow-1 main-content">
                    <div class="d-flex justify-content-between align-items-center p-3">
                        <h3 class="h3">Dashboard</h3>
                        <div>
                            <a href="#">Home</a> / Dashboard
                        </div>
                    </div>
                    <div class="row mx-0" style="padding: 0 5px 0 5px">
                        <div class="d-flex flex-column col top-card p-0" >
                            <div class="d-flex flex-grow-1 justify-content-between">
                                <div>
                                    <div class="top-card-text"><img class="project-shop-image" src="img-proyect/shops/image-asset.jpeg"></div>
                                    
                                </div>
                               
                            </div>
                            
                        </div>
                        <div class="d-flex flex-column col stop-card p-0" style="background: white; color: #424242;">
                            <div class="d-flex flex-grow-1 justify-content-between">
                                <div>
                                    <button class="btn btn-danger btn-lg float-center" >
                                        <i class="fa fa-thumbs-up"></i> View
                                    </button>
                                    
                                </div>
                                <div>
                                    <div class="stop-card-text">Satisfied Customers</div>
                                    <div class="top-card-label">410</div>
                                </div>
                                
                        </div>
                            
                        </div>
                        <div class="d-flex flex-column col stop-card p-0" style="background: white; color: #424242;">
                            <div class="d-flex flex-grow-1 justify-content-between">
                                <div>
                                    <button class="btn btn-success btn-lg float-center" >
                                        <i class="fa fa-shopping-cart"></i> View
                                    </button>
                                    
                                </div>
                                <div>
                                    <div class="stop-card-text">Sales</div>
                                    <div class="top-card-label">760</div>
                                </div>
                                
                        </div>
                            
                        </div>
                        <div class="d-flex flex-column col stop-card p-0" style="background: white; color: #424242;">
                            <div class="d-flex flex-grow-1 justify-content-between">
                                <div>
                                    <button class="btn btn-warning btn-lg float-center" >
                                        <i class="fa fa-users"></i> View
                                    </button>
                                    
                                </div>
                                <div>
                                    <div class="stop-card-text">New Members</div>
                                    <div class="top-card-label">200</div>
                                </div>
                                
                        </div>
                        
                    </div>
                    <div><img src="img-proyect/graph.jpeg" width="100%"></div>
                    <div class="row mx-0" style="padding: 0 5px 0 5px">
                        <div class="d-flex flex-column mb-3" ></div>
                            
                            <div class="card">
                                <div class="card-header bg-white">
                                    Latest Order
                                </div>
                                <table class="table mb-0">
                                    <thead>
                                        <tr>
                                            <th>Order ID</th>
                                            <th>Item</th>
                                            <th>Status</th>
                                            <th>Quantity</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td> <?php $qu= $pdo->prepare("SELECT order_id FROM product_order1 WHERE product_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?>
                                            <td>
                                                <div>
                                                    <div class="project-name"><?php $qu= $pdo->prepare("SELECT product_name FROM product_order1 WHERE product_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?></div>
                                                   </div>
                                            </td>
                                            
                                            <td>
                                            <button class="btn btn-success"; >
                                            <?php $qu= $pdo->prepare("SELECT status FROM product_order1 WHERE product_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?></div>
                                            </button>
                                        </td>
                                            <td>90,80,90,-70,61,-83,63</div></td>
                                            
                                        </tr>
                                        <tr>
                                            <td><?php $qu= $pdo->prepare("SELECT order_id FROM product_order1 WHERE product_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?></td>
                                            <td>
                                                <div>
                                                    <div class="project-name"><?php $qu= $pdo->prepare("SELECT product_name FROM product_order1 WHERE product_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?></div>
                                                   </div>
                                            </td>
                                            
                                            <td>
                                            <button class="btn btn-success"; >
																				  
                                            <?php $qu= $pdo->prepare("SELECT status FROM product_order1 WHERE product_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?>
																																		 
																																  
                                                            <?php echo $disp; ?></div>
                                            </button>
                                        </td>
                                            <td>90,80,90,-70,61,-83,63</div></td>
                                            
                                        </tr>
                                        <tr>
                                            <td><?php $qu= $pdo->prepare("SELECT order_id FROM product_order1 WHERE product_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?></td>
                                            <td>
                                                <div>
                                                    <div class="project-name"><?php $qu= $pdo->prepare("SELECT product_name FROM product_order1 WHERE product_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?></div>
                                                   </div>
                                            </td>
                                            
                                            <td>
                                            <button class="btn btn-success"; >
                                            <?php $qu= $pdo->prepare("SELECT status FROM product_order1 WHERE product_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?></div>
                                            </button>
                                        </td>
                                            <td>90,80,90,-70,61,-83,63</div></td>
                                            
                                        </tr>
                                        <tr>
                                            <td><?php $qu= $pdo->prepare("SELECT order_id FROM product_order1 WHERE product_id=?");
                                                            $qu->execute([++$x]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?></td>
                                            <td>
                                                <div>
                                                    <div class="project-name"><?php $qu= $pdo->prepare("SELECT product_name FROM product_order1 WHERE product_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?></div>
                                                   </div>
                                            </td>
                                            
                                            <td>
                                            <button class="btn btn-danger"; >
                                            <?php $qu= $pdo->prepare("SELECT status FROM product_order1 WHERE product_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?></div>
                                            </button>
                                        </td>
                                            <td>90,80,90,-70,61,-83,63</div></td>
                                            
                                        </tr>
                                        
                                        <tr>
                                        <td>
                                        <button class="btn btn-primary">Sort by New Orders</button>  
                                    </td>
                                    <td></td>
                                    <td></td>
                                    <td>
                                        <button class="btn btn-secondary" style="float: right;">View all Orders</button>  
                                    </td>
                                    </tr>
                                    </tbody>
                                    
                                </table>
                        </div>
                        
                        <div class="col row px-2" style="margin: 5px;">
                            <div class="d-flex flex-column mb-5" ></div>
                            <div class="misc d-flex align-items-center" style="background-color: #FDD835; color: #424242;">
                                <div>
                                    <i class="fa fa-tag"></i>
                                </div>
                                <div style="margin-left: 20px;">
                                    <div class="misc-title">Pending </div>
                                    <div class="misc-value">12</div>
                                </div>
                            </div>
                            
                            <div class="misc d-flex align-items-right" style="background-color: #F44336;">
                                <div>
                                    <i class="fa fa-check-circle"></i>
                                </div>
                                <div style="margin-left: 20px;">
                                    <div class="misc-title">Delivered</div>
                                    <div class="misc-value">1181</div>
                                </div>
                            </div>
                         
                            <div class="col row px-0" style="margin: 5px;">   
                            <div class="misc d-flex align-items-center" style="background-color: #43A047;">
                                <div>
                                    <i class="fa fa-heart-o"></i>
                                </div>
                                <div style="margin-left: 20px;">
                                    <div class="misc-title">Shipped</div>
                                    <div class="misc-value">950</div>
                                </div>
                            </div>
                            
                            <div class="misc d-flex align-items-center" style="background-color: #00ACC1;">
                                <div>
                                    <i class="fa fa-briefcase"></i>
                                </div>
                                <div style="margin-left: 20px;">
                                    <div class="misc-title">Processing</div>
                                    <div class="misc-value">321</div>
                                </div>
                            </div>
                        <div class="col  px-0 " style="margin: 5px;">
                            <div class="card">
                                <div class="card-header bg-white">
                                    Recently Added Products

                                </div>
                                <div class="card-body" style="padding: 10px">
                                    <div class="col mx-0">
                                        <div class="row-mb-1 d-flex flex-row   align-items-center px-0 member">
                                            <img class="member-image" src="<?php $qu= $pdo->prepare("select photo FROM product_order1 WHERE product_id=?");
                                                            $qu->execute([$x]);
                                                            $disp = $qu->fetchColumn();?>
                                                            <?php echo $disp; ?>">
                                            <div class="member-name" style=color:#0091EA>PRO Viper</div>
                                            <div class="member-time">Professional</div>
                                            <div button class="btn btn-primary btn-sm" style="float: right;">69</button></div> 
                                        </div>
                                        <div class="row-mb-1 d-flex flex-row   align-items-center px-0 member">
                                            <img class="member-image" src="img-proyect/BALL_02.jpg">
                                            <div class="member-name" style=color:#0091EA>BEACH BOAR</div>
                                            <div class="member-time">Medium speed</div>
                                            <div button class="btn btn-primary btn-sm" style="float: right;">29</button></div> 
                                        </div>
                                        <div class="row-mb-3 d-flex flex-row   align-items-center px-0 member">
                                            <img class="member-image" src="img-proyect/BRAZIL_04.jpg">
                                            <div class="member-name" style=color:#0091EA>PERFORMANCE BRAZIL</div>
                                            <div class="member-time">PERFORMANCE</div>
                                            <div button class="btn btn-primary btn-sm" style="float: right;">49</button></div> 
                                        </div>
                                        <div class="row-mb-3 d-flex flex-row   align-items-center px-0 member">
                                            <img class="member-image" src="img-proyect/FLAMINGO_04.jpg">
                                            <div class="member-name" style=color:#0091EA>PERFORMANCE Flamingo</div>
                                            <div class="member-time">PERFORMANCE</div>
                                            <div button class="btn btn-primary btn-sm" style="float: right;">49</button></div> 
                                        </div>
                                       
                                    </div>
                                </div>
                                <div class="card-footer text-center" style="border-top: none;">
                                    <a href="#">View all products</a>
                                </div>
                            </div>
                        </div>
                        
                        </div>
                    </div>
                </div>
                <footer class="page-footer" style="border-top: 1px solid #e0e0e0;">
                    <div class="footer-copyright py-3 pl-3" style="color: #9E9E9E; font-weight: bold;">
                        Copyright &copy; 2020 <a style="color: #0091EA;" href="#">DiazApps</a>. All rights reserved.
                    </div>
                </footer>
            </div>
        </div>

        <!-- Scripts -->
        <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
			crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
            crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
            crossorigin="anonymous"></script>
        <script src="js/script.js"></script>
    </body>
</html>