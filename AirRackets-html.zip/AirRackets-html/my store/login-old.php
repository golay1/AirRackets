
<!DOCTYPE html>
<html lang="en">
  <head>
	<title>AirRackets - Login</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
      crossorigin="anonymous">
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/loginstyle.css">
  </head>
    
	<body>
	<?php

$Err="";
require 'config.php';
function redirect($url)
{
    if (!headers_sent())
    {   
    session_regenerate_id(true); 
        header('Location: '.$url);
        die();
        }
    else
        {  
        echo '<script type="text/javascript">';
        echo 'window.location.href="'.$url.'";';
        echo '</script>';
        echo '<noscript>';
        echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
        echo '</noscript>'; die();
    }
}
if(isset($_POST['submit'])) {

$user = $_POST['email'];
$pass = $_POST['password'];

if(empty($user) || empty($pass)) {
$Err= "\nenter all fields";
} else {
$query = $pdo->prepare("SELECT email, password FROM user WHERE 
email=? AND password=? ");
$query->execute(array($user,$pass));
$row = $query->fetch(PDO::FETCH_BOTH);


if($query->rowCount() > 0) {
  $_SESSION['email'] = $user;
 echo"Signin Successful";
 $qu= $pdo->prepare("SELECT id FROM user WHERE email=?");
$qu->execute([$user]);
$varid = $qu->fetchColumn();
echo $varid;
$q= $pdo->prepare("SELECT usertype FROM user WHERE email=?");
$q->execute([$user]);
$usertype = $q->fetchColumn();
if($usertype== "gamer")
redirect("player-dashboard.php? varid= $varid");
if($usertype== "admin")
redirect("admin-dashboard.php? varid= $varid");
if($usertype== "store")
redirect("store-dashboard.php? varid= $varid");
exit();
} 
else{
 $Err="\nUsername/Password is wrong";
}
}
}

?>

	<style>
.error {color: #FF0000;}
</style>

	  <div class="logo">
         <img src="img-proyect/logo200x200.png">
      </div>
	  <div class="main">
        <p class="signinmsg" align="center">Sign in to start your session</p>
        <form class="form1" method="POST" >
          <input class="forminput" type="text" align="center" placeholder="Email" name="email" required>
		  <input class="password" type="password" align="center" placeholder="Password" name="password" required><span class="error" align="center"> <br> <?php echo $Err ?> </span>
		  <p class="remember_me">
		    <label><input type="checkbox" name="remember_me" id="remember_me">Remember me</label> 
          </p>
		  <button class="submit" align="right"  onclick="validateForm()"  name="submit" type="submit">Sign in</button>
          <p class="loginoptions" align="left"><a href="forgotpassword.php">I forgot my password</a></p>
		  <p class="loginoptions" align="left"><a href="register.php">Register a new membership</a></p>
		</form>
      </div>
     


 <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
      crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
      crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
      crossorigin="anonymous"></script>
    <script src="js/script.js"></script>
  </body>
</html>